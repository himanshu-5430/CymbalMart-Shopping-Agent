export type CategoryType = 
  | 'mains' 
  | 'appetizers' 
  | 'beverages' 
  | 'bakery' 
  | 'tableware' 
  | 'decor' 
  | 'essentials';

export type BrandTier = 'signature' | 'fresh' | 'premium' | 'value';

export type BudgetTierPreference = 'value' | 'balanced' | 'premium';

export interface EventConfig {
  eventName: string;
  partyType: string;
  theme: string;
  budget: number;
  guestCount: {
    adults: number;
    kids: number;
  };
  durationHours: number;
  dietaryRestrictions: string[];
  budgetTierPreference: BudgetTierPreference;
  specialRequests: string;
}

export interface AlternativeOption {
  name: string;
  brand: string;
  unitPrice: number;
  savingsOrUpgrade: string;
}

export interface ShoppingItem {
  id: string;
  name: string;
  brand: string;
  category: CategoryType;
  unitSize: string;
  unitPrice: number;
  quantity: number;
  tier: BrandTier;
  isMustHave: boolean;
  dietaryTags: string[];
  alternativeOption?: AlternativeOption;
  assignedGuest?: string;
}

export interface PortionAnalysis {
  adultServings: number;
  kidServings: number;
  estimatedDrinksCount: number;
  iceRequirementLbs: number;
  notes: string;
}

export interface PartyPrepTip {
  timeframe: string;
  task: string;
}

export interface PartyPlan {
  eventName: string;
  themeVibe: string;
  totalEstimatedCost: number;
  budgetVariance: number;
  costPerGuest: number;
  summaryNotes: string;
  portionAnalysis: PortionAnalysis;
  items: ShoppingItem[];
  partyPrepTips: PartyPrepTip[];
}

export interface StoreLocation {
  id: string;
  name: string;
  address: string;
  distance: string;
  curbsideBayCount: number;
  nextPickupSlot: string;
}

export interface FulfillmentDetails {
  method: 'pickup' | 'delivery';
  storeId: string;
  date: string;
  timeSlot: string;
  vehicleDescription?: string;
  deliveryAddress?: string;
  driverInstructions?: string;
  contactPhone: string;
  contactName: string;
}

export interface GuestAssignment {
  itemId: string;
  guestName: string;
  guestEmail?: string;
}
