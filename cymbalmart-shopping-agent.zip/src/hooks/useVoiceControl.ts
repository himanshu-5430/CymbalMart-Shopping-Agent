import { useState, useEffect, useRef, useCallback, Dispatch, SetStateAction } from 'react';
import { EventConfig, PartyPlan, ShoppingItem, BrandTier } from '../types/party';
import { PARTY_PRESETS } from '../data/cymbalmartData';

export interface VoiceCommandLog {
  id: string;
  transcript: string;
  actionTaken: string;
  success: boolean;
  timestamp: string;
}

interface UseVoiceControlProps {
  currentStep: number;
  setCurrentStep: (step: number) => void;
  config: EventConfig;
  setConfig: Dispatch<SetStateAction<EventConfig>>;
  plan: PartyPlan | null;
  setPlan: Dispatch<SetStateAction<PartyPlan | null>>;
  onGeneratePlan: () => Promise<void>;
  onRefineWithAI: (prompt: string) => Promise<void>;
  onReset: () => void;
  selectedFulfillment: 'pickup' | 'delivery';
  setSelectedFulfillment: (f: 'pickup' | 'delivery') => void;
  selectedBay: number;
  setSelectedBay: (bay: number) => void;
  pickupTime: string;
  setPickupTime: (time: string) => void;
  vehicleDetails: string;
  setVehicleDetails: (v: string) => void;
  orderCompleted: boolean;
  setOrderCompleted: (c: boolean) => void;
}

export function useVoiceControl({
  currentStep,
  setCurrentStep,
  config,
  setConfig,
  plan,
  setPlan,
  onGeneratePlan,
  onRefineWithAI,
  onReset,
  selectedFulfillment,
  setSelectedFulfillment,
  selectedBay,
  setSelectedBay,
  pickupTime,
  setPickupTime,
  vehicleDetails,
  setVehicleDetails,
  orderCompleted,
  setOrderCompleted
}: UseVoiceControlProps) {
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isSupported, setIsSupported] = useState<boolean>(true);
  const [transcript, setTranscript] = useState<string>('');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [lastAction, setLastAction] = useState<string | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [ttsEnabled, setTtsEnabled] = useState<boolean>(true);
  const [commandLogs, setCommandLogs] = useState<VoiceCommandLog[]>([]);
  const [isContinuous, setIsContinuous] = useState<boolean>(true);

  const recognitionRef = useRef<any>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const keepListeningRef = useRef<boolean>(false);

  // Initialize SpeechSynthesis
  useEffect(() => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  // Text-to-speech helper
  const speakFeedback = useCallback((text: string) => {
    if (!ttsEnabled || !synthRef.current) return;

    try {
      synthRef.current.cancel(); // stop previous
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      const voices = synthRef.current.getVoices();
      const preferredVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha')));
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      synthRef.current.speak(utterance);
    } catch (e) {
      console.warn('TTS playback issue:', e);
    }
  }, [ttsEnabled]);

  // Log action
  const logAction = useCallback((rawTranscript: string, actionMsg: string, success = true) => {
    setLastAction(actionMsg);
    setCommandLogs(prev => [
      {
        id: `cmd-${Date.now()}`,
        transcript: rawTranscript,
        actionTaken: actionMsg,
        success,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
      },
      ...prev.slice(0, 19)
    ]);
  }, []);

  // Process voice commands
  const processVoiceCommand = useCallback(async (spokenText: string) => {
    const raw = spokenText.trim();
    const text = raw.toLowerCase();
    if (!text) return;

    // 1. GLOBAL STEP NAVIGATION
    if (text.includes('go to step 1') || text.includes('define event') || text.includes('back to event') || text.includes('event setup')) {
      setCurrentStep(1);
      const msg = 'Navigated to Step 1: Define Event.';
      logAction(raw, msg);
      speakFeedback(msg);
      return;
    }

    if (text.includes('go to step 2') || text.includes('review list') || text.includes('view cart') || text.includes('show list')) {
      if (plan) {
        setCurrentStep(2);
        const msg = 'Navigated to Step 2: Review Shopping List.';
        logAction(raw, msg);
        speakFeedback(msg);
      } else {
        const msg = 'Please generate a shopping plan first in Step 1.';
        logAction(raw, msg, false);
        speakFeedback(msg);
      }
      return;
    }

    if (text.includes('go to step 3') || text.includes('go to checkout') || text.includes('proceed to checkout') || text.includes('checkout')) {
      if (plan) {
        setCurrentStep(3);
        const msg = 'Navigated to Step 3: Refine & Curbside Checkout.';
        logAction(raw, msg);
        speakFeedback(msg);
      } else {
        const msg = 'Please create a shopping plan first.';
        logAction(raw, msg, false);
        speakFeedback(msg);
      }
      return;
    }

    if (text.includes('reset plan') || text.includes('start over') || text.includes('clear party')) {
      onReset();
      const msg = 'Reset party plan. Ready for a new event.';
      logAction(raw, msg);
      speakFeedback(msg);
      return;
    }

    // 2. STEP 1 COMMANDS: DEFINE EVENT
    if (currentStep === 1) {
      // Archetype Preset Selection
      const matchedPreset = PARTY_PRESETS.find(p => 
        text.includes(p.title.toLowerCase()) || 
        text.includes(p.defaultConfig.partyType.toLowerCase()) ||
        (p.id === 'tropical-luau' && (text.includes('tropical') || text.includes('luau'))) ||
        (p.id === 'backyard-bbq' && text.includes('bbq')) ||
        (p.id === 'taco-fiesta' && (text.includes('taco') || text.includes('fiesta'))) ||
        (p.id === 'kids-birthday' && (text.includes('kids') || text.includes('birthday')))
      );

      if (text.startsWith('select preset') || text.startsWith('choose preset') || text.startsWith('apply preset') || matchedPreset) {
        if (matchedPreset) {
          setConfig({ ...matchedPreset.defaultConfig });
          const totalGuests = matchedPreset.defaultConfig.guestCount.adults + matchedPreset.defaultConfig.guestCount.kids;
          const msg = `Applied preset: ${matchedPreset.title} for ${totalGuests} guests with $${matchedPreset.defaultConfig.budget} budget.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Guest Count
      const guestMatch = text.match(/(\d+)\s*(total\s*)?guests/i) || text.match(/set guests to (\d+)/i) || text.match(/guests (\d+)/i);
      if (guestMatch) {
        const count = parseInt(guestMatch[1], 10);
        if (!isNaN(count) && count > 0) {
          setConfig(prev => ({
            ...prev,
            guestCount: { adults: Math.max(1, Math.round(count * 0.8)), kids: Math.round(count * 0.2) }
          }));
          const msg = `Set guest count to ${count} attendees.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Specific Adults/Kids
      const adultsMatch = text.match(/(\d+)\s*adults/i);
      const kidsMatch = text.match(/(\d+)\s*kids/i);
      if (adultsMatch || kidsMatch) {
        const adults = adultsMatch ? parseInt(adultsMatch[1], 10) : config.guestCount.adults;
        const kids = kidsMatch ? parseInt(kidsMatch[1], 10) : config.guestCount.kids;
        setConfig(prev => ({
          ...prev,
          guestCount: { adults: isNaN(adults) ? prev.guestCount.adults : adults, kids: isNaN(kids) ? prev.guestCount.kids : kids }
        }));
        const msg = `Updated guests to ${adults} adults and ${kids} kids.`;
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }

      // Budget
      const budgetMatch = text.match(/budget (?:of |to )?\$?(\d+)/i) || text.match(/set budget to \$?(\d+)/i) || text.match(/\$?(\d+)\s*dollars/i);
      if (budgetMatch) {
        const b = parseInt(budgetMatch[1], 10);
        if (!isNaN(b) && b > 0) {
          setConfig(prev => ({ ...prev, budget: b }));
          const msg = `Set budget to $${b}.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Theme
      if (text.includes('theme to') || text.includes('set theme') || text.includes('theme is')) {
        const themePart = raw.replace(/.*(?:theme to|set theme|theme is)\s+/i, '').trim();
        if (themePart) {
          setConfig(prev => ({ ...prev, theme: themePart }));
          const msg = `Set theme to "${themePart}".`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Event Name
      if (text.includes('event name to') || text.includes('name party to') || text.includes('name event')) {
        const namePart = raw.replace(/.*(?:event name to|name party to|name event to|name event)\s+/i, '').trim();
        if (namePart) {
          setConfig(prev => ({ ...prev, eventName: namePart }));
          const msg = `Set event name to "${namePart}".`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Dietary Toggles
      if (text.includes('vegan') || text.includes('vegetarian') || text.includes('gluten free') || text.includes('kid friendly')) {
        let tag = '';
        if (text.includes('vegan')) tag = 'Vegan';
        else if (text.includes('vegetarian')) tag = 'Vegetarian';
        else if (text.includes('gluten free') || text.includes('gluten-free')) tag = 'Gluten-Free';
        else if (text.includes('kid friendly') || text.includes('kid-friendly')) tag = 'Kid-Friendly';

        if (tag) {
          setConfig(prev => {
            const exists = prev.dietaryRestrictions.includes(tag);
            const updated = exists ? prev.dietaryRestrictions.filter(t => t !== tag) : [...prev.dietaryRestrictions, tag];
            const actionWord = exists ? 'Removed' : 'Added';
            const msg = `${actionWord} ${tag} dietary preference.`;
            logAction(raw, msg);
            speakFeedback(msg);
            return { ...prev, dietaryRestrictions: updated };
          });
          return;
        }
      }

      // Generate Plan
      if (text.includes('generate plan') || text.includes('generate list') || text.includes('create plan') || text.includes('build shopping list') || text.includes('next step')) {
        const msg = 'Curating CymbalMart shopping plan with portion modeling...';
        logAction(raw, msg);
        speakFeedback(msg);
        await onGeneratePlan();
        return;
      }
    }

    // 3. STEP 2 COMMANDS: REVIEW LIST & BUDGET OPTIMIZATION
    if (currentStep === 2 && plan) {
      // Auto-align budget
      if (text.includes('auto align') || text.includes('align budget') || text.includes('optimize budget') || text.includes('fit budget')) {
        let itemsCopy = [...plan.items];
        let runningCost = itemsCopy.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

        if (runningCost > config.budget) {
          // Switch premium to signature
          itemsCopy = itemsCopy.map(item => {
            if (item.tier === 'premium' && item.alternativeOption) {
              return {
                ...item,
                tier: 'signature' as BrandTier,
                brand: item.alternativeOption.brand,
                name: item.alternativeOption.name,
                unitPrice: item.alternativeOption.unitPrice
              };
            }
            return item;
          });

          // Trim non-essential items
          runningCost = itemsCopy.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
          if (runningCost > config.budget) {
            itemsCopy = itemsCopy.map(item => {
              if (!item.isMustHave && item.quantity > 1) {
                return { ...item, quantity: Math.max(1, item.quantity - 1) };
              }
              return item;
            });
          }
        }

        const newTotal = Number(itemsCopy.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0).toFixed(2));
        setPlan(prev => prev ? { ...prev, items: itemsCopy, totalEstimatedCost: newTotal } : null);
        const msg = `Auto-aligned shopping list. New total is $${newTotal.toFixed(2)} for your $${config.budget} budget.`;
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }

      // Brand Tier Global Swap
      if (text.includes('switch to signature') || text.includes('use signature brand')) {
        const updated = plan.items.map(item => {
          if (item.alternativeOption && item.alternativeOption.brand.toLowerCase().includes('signature')) {
            return {
              ...item,
              tier: 'signature' as BrandTier,
              brand: item.alternativeOption.brand,
              name: item.alternativeOption.name,
              unitPrice: item.alternativeOption.unitPrice
            };
          }
          return item;
        });
        const newTotal = Number(updated.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0).toFixed(2));
        setPlan(prev => prev ? { ...prev, items: updated, totalEstimatedCost: newTotal } : null);
        const msg = `Switched items to CymbalMart Signature brand. Total is now $${newTotal.toFixed(2)}.`;
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }

      // Quantity Increase / Decrease for specific items
      const increaseMatch = text.match(/(?:add more|increase|add)\s+([a-z\s]+)/i);
      const decreaseMatch = text.match(/(?:decrease|reduce|less)\s+([a-z\s]+)/i);
      const removeMatch = text.match(/(?:remove|delete)\s+([a-z\s]+)/i);

      if (increaseMatch || decreaseMatch || removeMatch) {
        const targetQuery = (increaseMatch?.[1] || decreaseMatch?.[1] || removeMatch?.[1] || '').trim();
        const found = plan.items.find(item => item.name.toLowerCase().includes(targetQuery));

        if (found) {
          if (removeMatch) {
            const updated = plan.items.filter(item => item.id !== found.id);
            const newTotal = Number(updated.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0).toFixed(2));
            setPlan(prev => prev ? { ...prev, items: updated, totalEstimatedCost: newTotal } : null);
            const msg = `Removed ${found.name} from shopping list.`;
            logAction(raw, msg);
            speakFeedback(msg);
            return;
          } else {
            const delta = increaseMatch ? 1 : -1;
            const updated = plan.items
              .map(item => item.id === found.id ? { ...item, quantity: Math.max(0, item.quantity + delta) } : item)
              .filter(item => item.quantity > 0);
            const newTotal = Number(updated.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0).toFixed(2));
            setPlan(prev => prev ? { ...prev, items: updated, totalEstimatedCost: newTotal } : null);
            const msg = `${increaseMatch ? 'Increased' : 'Decreased'} ${found.name} quantity. New total: $${newTotal.toFixed(2)}.`;
            logAction(raw, msg);
            speakFeedback(msg);
            return;
          }
        }
      }
    }

    // 4. STEP 3 COMMANDS: REFINE & CHECKOUT
    if (currentStep === 3) {
      // Fulfillment Mode
      if (text.includes('curbside') || text.includes('pickup') || text.includes('curbside pickup')) {
        setSelectedFulfillment('pickup');
        const msg = 'Selected Free Curbside Express Pickup.';
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }

      if (text.includes('delivery') || text.includes('home delivery')) {
        setSelectedFulfillment('delivery');
        const msg = 'Selected Refrigerated Home Delivery.';
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }

      // Bay Selection
      const bayMatch = text.match(/bay\s*(\d+)/i) || text.match(/select bay\s*(\d+)/i);
      if (bayMatch) {
        const bayNum = parseInt(bayMatch[1], 10);
        if (bayNum >= 1 && bayNum <= 16) {
          setSelectedBay(bayNum);
          const msg = `Selected Curbside Staging Bay ${bayNum}.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Time Slot
      if (text.includes('time to') || text.includes('pickup at') || text.includes('slot')) {
        const timePart = raw.replace(/.*(?:time to|pickup at|slot to)\s+/i, '').trim();
        if (timePart) {
          setPickupTime(timePart);
          const msg = `Updated pickup time window to ${timePart}.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // Vehicle
      if (text.includes('vehicle') || text.includes('car is') || text.includes('driving')) {
        const carPart = raw.replace(/.*(?:vehicle|car is|driving)\s+/i, '').trim();
        if (carPart) {
          setVehicleDetails(carPart);
          const msg = `Set vehicle details to: ${carPart}.`;
          logAction(raw, msg);
          speakFeedback(msg);
          return;
        }
      }

      // AI Refine Prompt
      if (text.startsWith('refine') || text.startsWith('modify') || text.startsWith('change plan') || text.includes('add vegan') || text.includes('more drinks')) {
        const refineInstruction = raw.replace(/^(?:refine|modify|change plan to)\s*/i, '');
        const msg = `Refining plan: "${refineInstruction}"`;
        logAction(raw, msg);
        speakFeedback('Refining shopping plan with your constraints...');
        await onRefineWithAI(refineInstruction);
        return;
      }

      // Final Order Confirmation
      if (text.includes('place order') || text.includes('confirm order') || text.includes('finish shopping') || text.includes('complete checkout')) {
        setOrderCompleted(true);
        const msg = 'Order placed successfully! Your CymbalMart Curbside Express Pass has been generated.';
        logAction(raw, msg);
        speakFeedback(msg);
        return;
      }
    }

    // Default Fallback
    logAction(raw, `Recognized: "${raw}"`, false);
  }, [
    currentStep,
    setCurrentStep,
    config,
    setConfig,
    plan,
    setPlan,
    onGeneratePlan,
    onRefineWithAI,
    onReset,
    setSelectedFulfillment,
    setSelectedBay,
    setPickupTime,
    setVehicleDetails,
    setOrderCompleted,
    logAction,
    speakFeedback
  ]);

  // Setup Web Speech Recognition
  const startListening = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      const msg = 'Web Speech Recognition is not supported in this browser. Please use Chrome or Edge.';
      logAction('Speech API', msg, false);
      return;
    }

    try {
      if (recognitionRef.current) {
        recognitionRef.current.abort();
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = isContinuous;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        keepListeningRef.current = isContinuous;
      };

      recognition.onresult = (event: any) => {
        let currentFinal = '';
        let currentInterim = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            currentFinal += event.results[i][0].transcript;
          } else {
            currentInterim += event.results[i][0].transcript;
          }
        }

        setInterimTranscript(currentInterim);

        if (currentFinal) {
          setTranscript(currentFinal);
          processVoiceCommand(currentFinal);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Voice recognition error:', event.error);
        if (event.error === 'not-allowed') {
          setIsListening(false);
          keepListeningRef.current = false;
          logAction('Microphone', 'Microphone access was denied. Please allow microphone permissions in your browser.', false);
        }
      };

      recognition.onend = () => {
        if (keepListeningRef.current) {
          try {
            recognition.start();
          } catch (e) {
            setIsListening(false);
          }
        } else {
          setIsListening(false);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
    }
  }, [isContinuous, logAction, processVoiceCommand]);

  const stopListening = useCallback(() => {
    keepListeningRef.current = false;
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsListening(false);
  }, []);

  const toggleListening = useCallback(() => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  }, [isListening, startListening, stopListening]);

  return {
    isListening,
    isSupported,
    transcript,
    interimTranscript,
    lastAction,
    isSpeaking,
    ttsEnabled,
    setTtsEnabled,
    commandLogs,
    isContinuous,
    setIsContinuous,
    startListening,
    stopListening,
    toggleListening,
    processVoiceCommand,
    speakFeedback
  };
}
