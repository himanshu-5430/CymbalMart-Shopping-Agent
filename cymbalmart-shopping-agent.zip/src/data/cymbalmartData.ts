import { CategoryType, StoreLocation, EventConfig } from '../types/party';

export interface CategoryMeta {
  id: CategoryType;
  label: string;
  shortLabel: string;
  iconName: string;
  colorClass: string;
  badgeBg: string;
  description: string;
}

export const CATEGORIES: Record<CategoryType, CategoryMeta> = {
  mains: {
    id: 'mains',
    label: 'Main Courses & Grills',
    shortLabel: 'Mains',
    iconName: 'UtensilsCrossed',
    colorClass: 'text-amber-700 border-amber-200 bg-amber-50',
    badgeBg: 'bg-amber-100 text-amber-800',
    description: 'Hearty central dishes, slider kits, BBQ proteins, and plant-based entrees.'
  },
  appetizers: {
    id: 'appetizers',
    label: 'Appetizers & Finger Foods',
    shortLabel: 'Starters',
    iconName: 'Salad',
    colorClass: 'text-emerald-700 border-emerald-200 bg-emerald-50',
    badgeBg: 'bg-emerald-100 text-emerald-800',
    description: 'Snack bites, artisan dips, charcuterie, veggie crisps, and party skewers.'
  },
  beverages: {
    id: 'beverages',
    label: 'Beverages, Mixers & Refreshments',
    shortLabel: 'Drinks',
    iconName: 'CupSoda',
    colorClass: 'text-cyan-700 border-cyan-200 bg-cyan-50',
    badgeBg: 'bg-cyan-100 text-cyan-800',
    description: 'Sparkling waters, craft sodas, cocktail mixers, juices, and specialty punches.'
  },
  bakery: {
    id: 'bakery',
    label: 'Bakery, Cakes & Sweet Treats',
    shortLabel: 'Bakery',
    iconName: 'Cake',
    colorClass: 'text-rose-700 border-rose-200 bg-rose-50',
    badgeBg: 'bg-rose-100 text-rose-800',
    description: 'Freshly baked celebration cakes, brownies, macarons, and dessert bites.'
  },
  tableware: {
    id: 'tableware',
    label: 'Tableware, Cups & Napkins',
    shortLabel: 'Tableware',
    iconName: 'Sparkles',
    colorClass: 'text-indigo-700 border-indigo-200 bg-indigo-50',
    badgeBg: 'bg-indigo-100 text-indigo-800',
    description: 'Compostable plates, cups, heavy-duty cutlery sets, tablecloths, and napkins.'
  },
  decor: {
    id: 'decor',
    label: 'Theme Decor & Atmosphere',
    shortLabel: 'Decor',
    iconName: 'PartyPopper',
    colorClass: 'text-purple-700 border-purple-200 bg-purple-50',
    badgeBg: 'bg-purple-100 text-purple-800',
    description: 'Garlands, letter banners, LED fairy lights, centerpieces, and photo props.'
  },
  essentials: {
    id: 'essentials',
    label: 'Ice, Condiments & Clean Up',
    shortLabel: 'Essentials',
    iconName: 'Boxes',
    colorClass: 'text-slate-700 border-slate-200 bg-slate-50',
    badgeBg: 'bg-slate-100 text-slate-800',
    description: 'Filtered cocktail ice, heavy trash bags, sanitizing wipes, foil, and sauces.'
  }
};

export interface PartyPreset {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  emoji: string;
  defaultConfig: EventConfig;
}

export const PARTY_PRESETS: PartyPreset[] = [
  {
    id: 'backyard-bbq',
    title: 'Backyard BBQ & Smokehouse',
    subtitle: 'Classic grilled burgers, pulled meats, crunchy slaws, craft seltzers',
    badge: 'Most Popular',
    emoji: '🍔',
    defaultConfig: {
      eventName: 'Summer Sizzle Backyard BBQ',
      partyType: 'Backyard BBQ',
      theme: 'Rustic Smokehouse & Outdoor Lawn Games',
      budget: 180,
      guestCount: { adults: 12, kids: 4 },
      durationHours: 4,
      dietaryRestrictions: ['Nut-Free Options'],
      budgetTierPreference: 'balanced',
      specialRequests: 'Include charcoal grill accessories, gourmet burger toppings, and lots of cocktail ice.'
    }
  },
  {
    id: 'taco-fiesta',
    title: 'Fiesta Taco & Nacho Bar',
    subtitle: 'Build-your-own tacos, fresh guacamole, queso dip, zesty mocktails & sodas',
    badge: 'Crowd Favorite',
    emoji: '🌮',
    defaultConfig: {
      eventName: 'Friday Fiesta Taco Bar',
      partyType: 'Taco Fiesta',
      theme: 'Vibrant Latin Fiesta & Mariachi Vibes',
      budget: 140,
      guestCount: { adults: 10, kids: 2 },
      durationHours: 3,
      dietaryRestrictions: ['Vegetarian', 'Gluten-Free'],
      budgetTierPreference: 'value',
      specialRequests: 'Mild salsa for kids, warm corn & flour tortillas, fresh limes, and compostable tableware.'
    }
  },
  {
    id: 'kids-birthday',
    title: 'Superhero & Arcade Birthday',
    subtitle: 'Mini pizza bites, fruit skewers, themed cupcakes, juice boxes & balloons',
    badge: 'Family Fun',
    emoji: '🦸‍♂️',
    defaultConfig: {
      eventName: 'Lucas 7th Superhero Adventure',
      partyType: 'Kids Birthday Party',
      theme: 'Cosmic Superhero Universe',
      budget: 160,
      guestCount: { adults: 8, kids: 12 },
      durationHours: 2.5,
      dietaryRestrictions: ['Nut-Free', 'Kid-Friendly'],
      budgetTierPreference: 'balanced',
      specialRequests: 'Nut-free bakery guarantee, juice pouches, themed photo props, and extra wet wipes.'
    }
  },
  {
    id: 'cocktail-tapas',
    title: 'Chic Tapas & Cocktail Soiree',
    subtitle: 'Artisan cheese boards, prosciutto skewers, sparkling seltzers, gourmet desserts',
    badge: 'Sophisticated',
    emoji: '🍸',
    defaultConfig: {
      eventName: 'Golden Hour Tapas & Mocktail Evening',
      partyType: 'Cocktail & Tapas Soiree',
      theme: 'Modern Minimalist Lounge & Ambient Beats',
      budget: 220,
      guestCount: { adults: 14, kids: 0 },
      durationHours: 3.5,
      dietaryRestrictions: ['Vegetarian Options'],
      budgetTierPreference: 'premium',
      specialRequests: 'Artisanal cheese platter, botanical mocktail mixers, crystal-clear ice, and bamboo skewers.'
    }
  },
  {
    id: 'game-night',
    title: 'Ultimate Board Game & Pizza Night',
    subtitle: 'Deep dish pizzas, warm spinach artichoke dip, giant cookie skillet, craft soda',
    badge: 'Cozy & Fun',
    emoji: '🎲',
    defaultConfig: {
      eventName: 'Epic Strategy Game Night',
      partyType: 'Game Night',
      theme: 'Casual Cozy Living Room Tournament',
      budget: 95,
      guestCount: { adults: 8, kids: 0 },
      durationHours: 4,
      dietaryRestrictions: [],
      budgetTierPreference: 'value',
      specialRequests: 'Mess-free finger snacks that won’t get cards oily, extra paper towels, and 2-liter drinks.'
    }
  },
  {
    id: 'sunshine-brunch',
    title: 'Sunday Mimosa & Pastry Brunch',
    subtitle: 'Fresh croissants, berry parfaits, mini quiches, cold brew coffee station',
    badge: 'Morning Social',
    emoji: '🥐',
    defaultConfig: {
      eventName: 'Sunshine Garden Brunch',
      partyType: 'Brunch Gathering',
      theme: 'Pastel Florals & Sunny Patio',
      budget: 130,
      guestCount: { adults: 10, kids: 2 },
      durationHours: 3,
      dietaryRestrictions: ['Vegetarian'],
      budgetTierPreference: 'balanced',
      specialRequests: 'Fresh organic berries, cold brew concentrate, oat milk, sparkling cider, and bakery croissants.'
    }
  }
];

export const CYMBALMART_STORES: StoreLocation[] = [
  {
    id: 'store-101',
    name: 'CymbalMart Supercenter - Downtown Metro',
    address: '450 Grand Avenue, Metro Plaza',
    distance: '1.2 miles away',
    curbsideBayCount: 16,
    nextPickupSlot: 'Today, 2:00 PM - 3:00 PM'
  },
  {
    id: 'store-102',
    name: 'CymbalMart Market & Fresh Bakery - West Valley',
    address: '880 Silicon Way, Westside Commons',
    distance: '3.8 miles away',
    curbsideBayCount: 24,
    nextPickupSlot: 'Today, 3:30 PM - 4:30 PM'
  },
  {
    id: 'store-103',
    name: 'CymbalMart Express - North Highlands',
    address: '1240 Pinecrest Blvd, North Hills',
    distance: '5.5 miles away',
    curbsideBayCount: 12,
    nextPickupSlot: 'Today, 4:00 PM - 5:00 PM'
  }
];

export const PICKUP_TIME_SLOTS = [
  'Today, 1:00 PM - 2:00 PM',
  'Today, 2:00 PM - 3:00 PM',
  'Today, 3:00 PM - 4:00 PM',
  'Today, 4:00 PM - 5:00 PM',
  'Today, 5:00 PM - 6:00 PM',
  'Tomorrow, 9:00 AM - 10:00 AM',
  'Tomorrow, 11:00 AM - 12:00 PM',
  'Tomorrow, 2:00 PM - 3:00 PM'
];

export const DIETARY_OPTIONS = [
  { id: 'vegetarian', label: 'Vegetarian Friendly', icon: '🥗' },
  { id: 'vegan', label: '100% Vegan', icon: '🌱' },
  { id: 'gluten-free', label: 'Gluten-Free Options', icon: '🌾' },
  { id: 'nut-free', label: 'Strictly Nut-Free', icon: '🥜' },
  { id: 'dairy-free', label: 'Dairy-Free Alternatives', icon: '🥛' },
  { id: 'kid-friendly', label: 'Kid-Friendly Menu', icon: '👶' },
  { id: 'non-alcoholic', label: 'Non-Alcoholic / Mocktails', icon: '🍹' },
  { id: 'halal-kosher', label: 'Halal / Kosher Preferred', icon: '✨' },
  { id: 'eco-friendly', label: 'Compostable Tableware', icon: '♻️' }
];
