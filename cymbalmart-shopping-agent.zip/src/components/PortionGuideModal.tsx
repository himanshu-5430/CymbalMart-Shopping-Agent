import React from 'react';
import { X, Users, CupSoda, Utensils, Sparkles, Scale } from 'lucide-react';
import { PortionAnalysis } from '../types/party';

interface PortionGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  analysis?: PortionAnalysis;
  totalGuests: number;
  durationHours: number;
}

export const PortionGuideModal: React.FC<PortionGuideModalProps> = ({
  isOpen,
  onClose,
  analysis,
  totalGuests,
  durationHours
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1A1A1A]/80 backdrop-blur-xs">
      <div className="bg-white border-2 border-[#1A1A1A] max-w-xl w-full p-6 sm:p-8 relative text-left">
        <button
          id="close-portion-modal-btn"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#1A1A1A]/50 hover:text-[#1A1A1A] hover:bg-[#F1F0EA] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#8B2131] block mb-1">
            Calculated Catering Ratios
          </span>
          <h3 className="text-2xl font-black uppercase tracking-tight text-[#1A1A1A]">
            Event Portion Calculator
          </h3>
          <p className="text-xs text-[#1A1A1A]/60 font-medium font-mono">
            Calibrated for {totalGuests} guests over a {durationHours}-hour runtime
          </p>
        </div>

        <div className="space-y-5">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-left">
            <div className="p-3.5 border border-[#1A1A1A]/10 bg-[#F9F8F3]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/50 block">Adult Mains</span>
              <span className="text-2xl font-black font-mono text-[#1A1A1A] mt-0.5 block">{analysis?.adultServings || totalGuests}</span>
              <span className="text-[9px] font-mono text-[#1A1A1A]/40 uppercase block">1.2x Safety Ratio</span>
            </div>

            <div className="p-3.5 border border-[#1A1A1A]/10 bg-[#F9F8F3]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/50 block">Total Drinks</span>
              <span className="text-2xl font-black font-mono text-[#1A1A1A] mt-0.5 block">{analysis?.estimatedDrinksCount || totalGuests * 3}</span>
              <span className="text-[9px] font-mono text-[#1A1A1A]/40 uppercase block">2+1/hr rate</span>
            </div>

            <div className="p-3.5 border border-[#1A1A1A]/10 bg-[#F9F8F3]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/50 block">Ice Required</span>
              <span className="text-2xl font-black font-mono text-[#8B2131] mt-0.5 block">{analysis?.iceRequirementLbs || Math.round(totalGuests * 1.5)} lbs</span>
              <span className="text-[9px] font-mono text-[#1A1A1A]/40 uppercase block">1.5 lbs / Guest</span>
            </div>

            <div className="p-3.5 border border-[#1A1A1A]/10 bg-[#F9F8F3]">
              <span className="text-[9px] font-bold uppercase tracking-widest text-[#1A1A1A]/50 block">Appetizers</span>
              <span className="text-2xl font-black font-mono text-[#1A1A1A] mt-0.5 block">{totalGuests * 5} pcs</span>
              <span className="text-[9px] font-mono text-[#1A1A1A]/40 uppercase block">5-6 bites/guest</span>
            </div>
          </div>

          <div className="p-4 border border-[#1A1A1A]/10 bg-[#F9F8F3] space-y-2 text-xs text-[#1A1A1A]">
            <h4 className="font-bold uppercase tracking-wider text-xs flex items-center text-[#8B2131]">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" />
              Event Planning Best Practice Rules
            </h4>
            <ul className="list-disc list-inside space-y-1 text-[#1A1A1A]/80 leading-relaxed font-medium">
              <li><strong>Proteins & Mains:</strong> 6-8 oz per adult for grilled meats; 2-3 sliders or tacos per person.</li>
              <li><strong>Sides & Salads:</strong> 4 oz per guest for pasta/potato salads and grilled veggies.</li>
              <li><strong>Ice Distribution:</strong> Half for chilling bottles/cans in coolers, half for drinking in glasses.</li>
              <li><strong>Tableware Multiplier:</strong> We recommend 1.5 plates and 2 cups per guest to account for multiple beverage types.</li>
            </ul>
          </div>

          {analysis?.notes && (
            <div className="p-3 bg-[#8B2131]/5 border-l-4 border-[#8B2131] text-xs text-[#1A1A1A]">
              <strong className="uppercase font-bold text-[#8B2131] text-[10px] tracking-wider block mb-0.5">Agent Note</strong>
              <p className="text-[#1A1A1A]/80">{analysis.notes}</p>
            </div>
          )}
        </div>

        <div className="mt-6 pt-4 border-t border-[#1A1A1A]/10 flex justify-end">
          <button
            id="close-portion-guide-action"
            type="button"
            onClick={onClose}
            className="px-6 py-2.5 text-[10px] font-black uppercase tracking-[0.2em] text-white bg-[#1A1A1A] hover:bg-[#8B2131] transition-colors"
          >
            Acknowledge
          </button>
        </div>
      </div>
    </div>
  );
};
