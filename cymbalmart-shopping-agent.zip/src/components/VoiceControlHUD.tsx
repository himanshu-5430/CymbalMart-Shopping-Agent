import React, { useState } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Command,
  ChevronUp,
  ChevronDown,
  X,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Play,
  RotateCcw
} from 'lucide-react';
import { VoiceCommandLog } from '../hooks/useVoiceControl';

interface VoiceControlHUDProps {
  isListening: boolean;
  isSupported: boolean;
  transcript: string;
  interimTranscript: string;
  lastAction: string | null;
  isSpeaking: boolean;
  ttsEnabled: boolean;
  onToggleTTS: () => void;
  onToggleListening: () => void;
  commandLogs: VoiceCommandLog[];
  currentStep: number;
  onSimulateCommand: (command: string) => void;
}

export const VoiceControlHUD: React.FC<VoiceControlHUDProps> = ({
  isListening,
  isSupported,
  transcript,
  interimTranscript,
  lastAction,
  isSpeaking,
  ttsEnabled,
  onToggleTTS,
  onToggleListening,
  commandLogs,
  currentStep,
  onSimulateCommand
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [showCheatsheet, setShowCheatsheet] = useState<boolean>(false);
  const [testInput, setTestInput] = useState<string>('');

  // Step specific voice suggestions
  const getStepSuggestions = () => {
    switch (currentStep) {
      case 1:
        return [
          { text: 'Set guests to 20', desc: 'Adjusts total attendee math' },
          { text: 'Set theme to Tropical', desc: 'Calibrates food & decor vibe' },
          { text: 'Set budget to 250 dollars', desc: 'Sets spending ceiling' },
          { text: 'Select Tropical Luau preset', desc: 'Applies complete archetype' },
          { text: 'Add Vegetarian preference', desc: 'Toggles dietary accommodation' },
          { text: 'Generate shopping plan', desc: 'Proceeds to curated list' }
        ];
      case 2:
        return [
          { text: 'Auto align budget', desc: 'Optimizes quantities & tiers to fit budget' },
          { text: 'Switch to Signature brand', desc: 'Applies CymbalMart Signature savings' },
          { text: 'Switch to Value brand', desc: 'Applies Everyday Value discount' },
          { text: 'Add more ice', desc: 'Increases ice portion by 1 bag' },
          { text: 'Remove paper plates', desc: 'Deletes item from list' },
          { text: 'Go to checkout', desc: 'Advances to Step 3' }
        ];
      case 3:
        return [
          { text: 'Choose Curbside pickup', desc: 'Sets free bay loading' },
          { text: 'Select Bay 4', desc: 'Reserves express staging bay' },
          { text: 'Set time to 2 PM', desc: 'Schedules staging slot' },
          { text: 'Vehicle Silver Subaru', desc: 'Stores loading car identity' },
          { text: 'Place order', desc: 'Completes checkout & gives bay pass' },
          { text: 'Go to step 1', desc: 'Navigates back to setup' }
        ];
      default:
        return [];
    }
  };

  return (
    <>
      {/* Floating Voice Control HUD Pill (Bottom Center) */}
      <aside 
        aria-label="Voice Control Status"
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center shadow-2xl transition-all"
      >
        <div className={`flex items-center p-1.5 border-2 transition-all ${
          isListening 
            ? 'bg-[#1A1A1A] border-[#8B2131] text-white ring-4 ring-[#8B2131]/20' 
            : 'bg-white border-[#1A1A1A] text-[#1A1A1A]'
        }`}>
          
          {/* Mic Toggle Button */}
          <button
            id="voice-mic-main-toggle"
            onClick={onToggleListening}
            title={isListening ? 'Stop Hands-Free Listening' : 'Start Hands-Free Voice Control'}
            className={`flex items-center space-x-2 px-3.5 py-2 font-black text-xs uppercase tracking-wider transition-all cursor-pointer ${
              isListening
                ? 'bg-[#8B2131] text-white animate-pulse'
                : 'bg-[#1A1A1A] text-white hover:bg-[#8B2131]'
            }`}
          >
            {isListening ? (
              <>
                <Mic className="w-4 h-4 text-amber-300 animate-bounce" />
                <span>Listening...</span>
              </>
            ) : (
              <>
                <Mic className="w-4 h-4 text-white" />
                <span>Voice Control</span>
              </>
            )}
          </button>

          {/* Real-time speech preview / status */}
          <div 
            onClick={() => setIsOpen(true)}
            className="px-3 py-1 text-left cursor-pointer hidden sm:block max-w-[240px] truncate"
          >
            {isListening ? (
              <div>
                <p className="text-[10px] font-mono font-bold text-amber-400 truncate">
                  {interimTranscript || transcript || 'Say "Set guests to 20" or "Help"...'}
                </p>
                <p className="text-[8px] font-mono opacity-60 uppercase tracking-widest">
                  Hands-Free Active
                </p>
              </div>
            ) : (
              <div>
                <p className="text-[10px] font-bold uppercase tracking-wider truncate">
                  {lastAction || 'Speak commands hands-free'}
                </p>
                <p className="text-[8px] font-mono opacity-50 uppercase tracking-widest">
                  Click to open Voice Hub
                </p>
              </div>
            )}
          </div>

          {/* Sound Wave Bars when active */}
          {isListening && (
            <div className="flex items-center space-x-0.5 px-2">
              <span className="w-1 h-3 bg-amber-400 rounded-full animate-pulse" />
              <span className="w-1 h-5 bg-[#8B2131] rounded-full animate-pulse [animation-delay:0.15s]" />
              <span className="w-1 h-2 bg-emerald-400 rounded-full animate-pulse [animation-delay:0.3s]" />
              <span className="w-1 h-4 bg-amber-400 rounded-full animate-pulse [animation-delay:0.45s]" />
            </div>
          )}

          {/* Audio Feedback (TTS) Toggle */}
          <button
            id="voice-tts-toggle"
            onClick={onToggleTTS}
            title={ttsEnabled ? 'Voice confirmation is ON (Click to mute)' : 'Voice confirmation is OFF (Click to unmute)'}
            className={`p-2 transition-colors cursor-pointer border-l ${
              isListening ? 'border-white/20 text-white/80 hover:text-white' : 'border-[#1A1A1A]/20 text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            {ttsEnabled ? (
              <Volume2 className={`w-3.5 h-3.5 ${isSpeaking ? 'text-amber-400 animate-pulse' : ''}`} />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-red-400" />
            )}
          </button>

          {/* Expand HUD Drawer */}
          <button
            id="voice-hud-expand-btn"
            onClick={() => setIsOpen(!isOpen)}
            title="Open Voice Command Hub"
            className={`p-2 transition-colors cursor-pointer ${
              isListening ? 'text-white/80 hover:text-white' : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
            }`}
          >
            <ChevronUp className={`w-3.5 h-3.5 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </aside>

      {/* Voice Control Modal / Command Center Drawer */}
      {isOpen && (
        <div 
          role="dialog"
          aria-modal="true"
          aria-labelledby="voice-control-hub-title"
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-end sm:items-center justify-center p-3 sm:p-4"
        >
          <div 
            id="voice-control-hub-modal"
            className="bg-[#F9F8F3] border-2 border-[#1A1A1A] shadow-2xl w-full max-w-xl max-h-[90vh] flex flex-col animate-in fade-in zoom-in-95"
          >
            {/* Header */}
            <div className="p-4 bg-[#1A1A1A] text-white flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="w-7 h-7 bg-[#8B2131] flex items-center justify-center text-white font-bold">
                  <Mic className="w-4 h-4 text-amber-300" />
                </div>
                <div>
                  <h3 id="voice-control-hub-title" className="text-xs font-black uppercase tracking-wider text-white">
                    CymbalMart Hands-Free Voice Center
                  </h3>
                  <p className="text-[9px] font-mono text-white/60 uppercase tracking-widest">
                    Complete your entire party shopping journey with your voice
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  id="toggle-tts-in-modal"
                  onClick={onToggleTTS}
                  className={`flex items-center space-x-1.5 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider border transition-colors ${
                    ttsEnabled ? 'bg-white text-[#1A1A1A] border-white' : 'bg-transparent text-white/60 border-white/30'
                  }`}
                >
                  {ttsEnabled ? <Volume2 className="w-3 h-3 text-[#8B2131]" /> : <VolumeX className="w-3 h-3" />}
                  <span>{ttsEnabled ? 'Voice Confirm: ON' : 'Muted'}</span>
                </button>

                <button
                  id="close-voice-hub-btn"
                  onClick={() => setIsOpen(false)}
                  className="p-1 text-white/70 hover:text-white hover:bg-[#8B2131] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Active Speech Bar */}
            <div className="p-4 bg-white border-b border-[#1A1A1A]/10">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className={`w-2.5 h-2.5 rounded-full ${isListening ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`} />
                  <span className="text-[11px] font-black uppercase tracking-wider font-mono text-[#1A1A1A]">
                    {isListening ? 'Live Microphone Active' : 'Microphone Paused'}
                  </span>
                </div>
                <button
                  onClick={onToggleListening}
                  className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest ${
                    isListening ? 'bg-[#8B2131] text-white' : 'bg-[#1A1A1A] text-white'
                  }`}
                >
                  {isListening ? 'Stop Listening' : 'Start Listening'}
                </button>
              </div>

              {/* Transcript Display */}
              <div className="p-3 bg-[#F1F0EA] border border-[#1A1A1A]/20 min-h-[56px] flex flex-col justify-center">
                <span className="text-[9px] font-mono uppercase text-[#1A1A1A]/50 font-bold mb-1">
                  Recognized Speech:
                </span>
                <p className="text-sm font-mono font-bold text-[#1A1A1A]">
                  {interimTranscript || transcript || (
                    <span className="text-[#1A1A1A]/40 italic font-normal">
                      Speak naturally, e.g., "Set guests to 20", "Auto align budget", or "Select pickup bay 4"
                    </span>
                  )}
                </p>
              </div>

              {lastAction && (
                <div className="mt-2.5 flex items-center space-x-2 text-xs font-mono text-emerald-800 bg-emerald-50 px-2.5 py-1.5 border border-emerald-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="truncate"><strong>Action:</strong> {lastAction}</span>
                </div>
              )}
            </div>

            {/* Step-Specific Voice Command Shortcuts */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 text-left">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-[11px] font-black uppercase tracking-wider text-[#1A1A1A] flex items-center">
                    <Command className="w-3.5 h-3.5 mr-1.5 text-[#8B2131]" />
                    <span>Quick Spoken Commands for Step 0{currentStep}</span>
                  </h4>
                  <span className="text-[9px] font-mono bg-[#8B2131]/10 text-[#8B2131] font-bold px-2 py-0.5">
                    Click to test command
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {getStepSuggestions().map((cmd, idx) => (
                    <button
                      key={idx}
                      onClick={() => onSimulateCommand(cmd.text)}
                      className="p-2.5 bg-white border border-[#1A1A1A]/15 hover:border-[#1A1A1A] hover:bg-[#F1F0EA] text-left transition-all group cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-black text-[#1A1A1A] group-hover:text-[#8B2131]">
                          "{cmd.text}"
                        </span>
                        <Play className="w-2.5 h-2.5 text-[#1A1A1A]/40 group-hover:text-[#8B2131]" />
                      </div>
                      <p className="text-[10px] text-[#1A1A1A]/60 mt-0.5">
                        {cmd.desc}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Full Command Matrix Cheatsheet */}
              <div className="border border-[#1A1A1A]/15 bg-white p-3">
                <button
                  onClick={() => setShowCheatsheet(!showCheatsheet)}
                  className="w-full flex items-center justify-between text-xs font-bold uppercase tracking-wider text-[#1A1A1A]"
                >
                  <span className="flex items-center space-x-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-[#8B2131]" />
                    <span>Full Hands-Free Voice Vocabulary</span>
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 transition-transform ${showCheatsheet ? 'rotate-180' : ''}`} />
                </button>

                {showCheatsheet && (
                  <div className="mt-3 pt-3 border-t border-[#1A1A1A]/10 space-y-3 text-[11px]">
                    <div>
                      <h5 className="font-bold text-[#8B2131] uppercase tracking-wider text-[10px] font-mono mb-1">
                        Step 1: Event Context
                      </h5>
                      <p className="text-[#1A1A1A]/80 font-mono text-[10px] leading-relaxed">
                        • "Set guests to [number]" / "16 adults and 4 kids"<br />
                        • "Set theme to [Tropical / BBQ / Fiesta / Retro]"<br />
                        • "Set budget to [amount] dollars"<br />
                        • "Select [Summer BBQ / Tropical Luau / Taco Fiesta] preset"<br />
                        • "Add [Vegan / Vegetarian / Gluten-Free] preference"<br />
                        • "Generate shopping plan" / "Next step"
                      </p>
                    </div>

                    <div>
                      <h5 className="font-bold text-[#8B2131] uppercase tracking-wider text-[10px] font-mono mb-1">
                        Step 2: Cart & Brands
                      </h5>
                      <p className="text-[#1A1A1A]/80 font-mono text-[10px] leading-relaxed">
                        • "Auto align budget" / "Optimize budget"<br />
                        • "Switch to Signature brand" / "Switch to Value brand"<br />
                        • "Add more [item name]" / "Increase [item name]"<br />
                        • "Remove [item name]" / "Delete [item name]"<br />
                        • "Go to checkout" / "Proceed to step 3"
                      </p>
                    </div>

                    <div>
                      <h5 className="font-bold text-[#8B2131] uppercase tracking-wider text-[10px] font-mono mb-1">
                        Step 3: Fulfillment & Order Pass
                      </h5>
                      <p className="text-[#1A1A1A]/80 font-mono text-[10px] leading-relaxed">
                        • "Choose Curbside pickup" / "Select Home delivery"<br />
                        • "Select Bay [1 through 16]"<br />
                        • "Set time to [2 PM / 4:30 PM]"<br />
                        • "Vehicle [Make and Color]"<br />
                        • "Place order" / "Confirm order" / "Complete checkout"
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {/* Manual Voice Simulator Input (For zero-mic environments) */}
              <div className="p-3 bg-[#F1F0EA] border border-[#1A1A1A]/10">
                <span className="text-[10px] font-mono font-bold uppercase text-[#1A1A1A]/70 block mb-1.5">
                  Manual Command Tester (Type or speak):
                </span>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (testInput.trim()) {
                      onSimulateCommand(testInput.trim());
                      setTestInput('');
                    }
                  }}
                  className="flex items-center space-x-2"
                >
                  <input
                    type="text"
                    value={testInput}
                    onChange={(e) => setTestInput(e.target.value)}
                    placeholder='Try "Set guests to 20" or "Auto align budget"...'
                    className="flex-1 px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-white text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 bg-[#1A1A1A] text-white hover:bg-[#8B2131] text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    Execute
                  </button>
                </form>
              </div>

              {/* Recent Voice Activity Log */}
              {commandLogs.length > 0 && (
                <div>
                  <h4 className="text-[10px] font-mono font-bold uppercase tracking-wider text-[#1A1A1A]/60 mb-1.5">
                    Recent Spoken Actions:
                  </h4>
                  <div className="space-y-1.5 max-h-28 overflow-y-auto">
                    {commandLogs.slice(0, 5).map((log) => (
                      <div key={log.id} className="text-[10px] font-mono p-1.5 bg-white border border-[#1A1A1A]/10 flex items-center justify-between">
                        <div className="truncate flex-1 mr-2">
                          <span className="font-bold text-[#1A1A1A]">"{log.transcript}"</span>
                          <span className="text-[#1A1A1A]/60 ml-2">→ {log.actionTaken}</span>
                        </div>
                        <span className="text-[#1A1A1A]/40 shrink-0">{log.timestamp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-[#F1F0EA] border-t border-[#1A1A1A]/15 flex items-center justify-between text-[11px]">
              <span className="font-mono text-[#1A1A1A]/60 text-[10px]">
                Powered by CymbalMart Speech Voice Engine
              </span>
              <button
                onClick={() => setIsOpen(false)}
                className="px-4 py-1.5 bg-[#1A1A1A] text-white text-xs font-bold uppercase tracking-wider hover:bg-[#8B2131] transition-colors"
              >
                Close Hub
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
