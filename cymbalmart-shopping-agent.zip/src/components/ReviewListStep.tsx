import React, { useState, useMemo } from 'react';
import { 
  Plus, 
  Trash2, 
  ArrowRight, 
  Info, 
  Search, 
  AlertCircle,
  ShieldCheck,
  Zap,
  Layers
} from 'lucide-react';
import { PartyPlan, ShoppingItem, CategoryType, EventConfig } from '../types/party';
import { CATEGORIES } from '../data/cymbalmartData';
import { AddCustomItemModal } from './AddCustomItemModal';
import { PortionGuideModal } from './PortionGuideModal';

interface ReviewListStepProps {
  plan: PartyPlan;
  config: EventConfig;
  onUpdatePlan: (newPlan: PartyPlan) => void;
  onProceedToCheckout: () => void;
  onBackToDefine: () => void;
}

export const ReviewListStep: React.FC<ReviewListStepProps> = ({
  plan,
  config,
  onUpdatePlan,
  onProceedToCheckout,
  onBackToDefine
}) => {
  const [selectedCategory, setSelectedCategory] = useState<CategoryType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMustHaveOnly, setFilterMustHaveOnly] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPortionModalOpen, setIsPortionModalOpen] = useState(false);
  const [lastRemovedItem, setLastRemovedItem] = useState<ShoppingItem | null>(null);

  const totalGuests = (config.guestCount.adults || 0) + (config.guestCount.kids || 0) || 1;
  const targetBudget = config.budget;

  // Calculate live totals
  const currentTotal = useMemo(() => {
    return plan.items.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  }, [plan.items]);

  const budgetVariance = targetBudget - currentTotal;
  const isOverBudget = currentTotal > targetBudget;
  const costPerGuest = +(currentTotal / totalGuests).toFixed(2);
  const budgetPercentage = Math.min(100, Math.round((currentTotal / targetBudget) * 100));

  // Category subtotals
  const categorySubtotals = useMemo(() => {
    const map: Record<string, { count: number; subtotal: number }> = {};
    Object.keys(CATEGORIES).forEach((cat) => {
      map[cat] = { count: 0, subtotal: 0 };
    });
    plan.items.forEach((item) => {
      if (map[item.category]) {
        map[item.category].count += item.quantity;
        map[item.category].subtotal += item.unitPrice * item.quantity;
      }
    });
    return map;
  }, [plan.items]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return plan.items.filter((item) => {
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      if (filterMustHaveOnly && !item.isMustHave) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(q);
        const matchBrand = item.brand.toLowerCase().includes(q);
        const matchDiet = item.dietaryTags.some((t) => t.toLowerCase().includes(q));
        if (!matchName && !matchBrand && !matchDiet) return false;
      }
      return true;
    });
  }, [plan.items, selectedCategory, filterMustHaveOnly, searchQuery]);

  // Update item quantity directly
  const handleDirectQuantitySet = (itemId: string, qty: number) => {
    const validQty = Math.max(0, isNaN(qty) ? 0 : qty);
    const updatedItems = plan.items
      .map((item) => {
        if (item.id === itemId) {
          return { ...item, quantity: validQty };
        }
        return item;
      })
      .filter((item) => item.quantity > 0);

    recalculateAndSetPlan(updatedItems);
  };

  // Update item unit price directly
  const handleDirectPriceSet = (itemId: string, price: number) => {
    const validPrice = Math.max(0.01, isNaN(price) ? 0.01 : price);
    const updatedItems = plan.items.map((item) => {
      if (item.id === itemId) {
        return { ...item, unitPrice: Number(validPrice.toFixed(2)) };
      }
      return item;
    });

    recalculateAndSetPlan(updatedItems);
  };

  // Update item quantity
  const handleQuantityChange = (itemId: string, delta: number) => {
    const updatedItems = plan.items
      .map((item) => {
        if (item.id === itemId) {
          const newQty = Math.max(0, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      })
      .filter((item) => item.quantity > 0);

    recalculateAndSetPlan(updatedItems);
  };

  // Toggle must-have flag
  const handleToggleMustHave = (itemId: string) => {
    const updatedItems = plan.items.map((item) => {
      if (item.id === itemId) {
        return { ...item, isMustHave: !item.isMustHave };
      }
      return item;
    });
    recalculateAndSetPlan(updatedItems);
  };

  // Remove item
  const handleRemoveItem = (itemId: string) => {
    const itemToRemove = plan.items.find((i) => i.id === itemId);
    if (itemToRemove) {
      setLastRemovedItem(itemToRemove);
    }
    const updatedItems = plan.items.filter((item) => item.id !== itemId);
    recalculateAndSetPlan(updatedItems);
  };

  // Undo remove
  const handleUndoRemove = () => {
    if (lastRemovedItem) {
      const updatedItems = [...plan.items, lastRemovedItem];
      setLastRemovedItem(null);
      recalculateAndSetPlan(updatedItems);
    }
  };

  // Swap to alternative option
  const handleSwapAlternative = (item: ShoppingItem) => {
    if (!item.alternativeOption) return;

    const alt = item.alternativeOption;
    const currentName = item.name;
    const currentBrand = item.brand;
    const currentPrice = item.unitPrice;

    const updatedItems = plan.items.map((it) => {
      if (it.id === item.id) {
        return {
          ...it,
          name: alt.name,
          brand: alt.brand,
          unitPrice: alt.unitPrice,
          tier: (alt.brand.includes('CymbalMart') ? 'signature' : 'fresh') as any,
          alternativeOption: {
            name: currentName,
            brand: currentBrand,
            unitPrice: currentPrice,
            savingsOrUpgrade: 'Revert to previous selection'
          }
        };
      }
      return it;
    });

    recalculateAndSetPlan(updatedItems);
  };

  // Add custom item
  const handleAddCustomItem = (newItem: ShoppingItem) => {
    const updatedItems = [newItem, ...plan.items];
    recalculateAndSetPlan(updatedItems);
  };

  // Auto-align to budget: swap premium items to CymbalMart Signature or trim optional
  const handleAutoAlignBudget = () => {
    let updatedItems = plan.items.map((item) => {
      if (item.tier === 'premium' && item.alternativeOption) {
        return {
          ...item,
          name: item.alternativeOption.name,
          brand: item.alternativeOption.brand,
          unitPrice: item.alternativeOption.unitPrice,
          tier: 'signature' as any
        };
      }
      return item;
    });

    // Check if still over budget, if so reduce optional items
    let calcSum = updatedItems.reduce((sum, it) => sum + it.unitPrice * it.quantity, 0);
    if (calcSum > targetBudget) {
      updatedItems = updatedItems.map((it) => {
        if (!it.isMustHave && it.quantity > 1) {
          return { ...it, quantity: it.quantity - 1 };
        }
        return it;
      });
    }

    recalculateAndSetPlan(updatedItems);
  };

  const recalculateAndSetPlan = (items: ShoppingItem[]) => {
    const newTotal = items.reduce((acc, it) => acc + it.unitPrice * it.quantity, 0);
    const newPlan: PartyPlan = {
      ...plan,
      items,
      totalEstimatedCost: Number(newTotal.toFixed(2)),
      budgetVariance: Number((targetBudget - newTotal).toFixed(2)),
      costPerGuest: Number((newTotal / totalGuests).toFixed(2))
    };
    onUpdatePlan(newPlan);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-left">
      
      {/* Undo Banner */}
      {lastRemovedItem && (
        <div className="mb-6 p-4 bg-[#1A1A1A] text-white flex items-center justify-between text-xs font-bold uppercase tracking-wider animate-in slide-in-from-top-2 border-l-4 border-[#8B2131]">
          <span>Removed <strong>{lastRemovedItem.name}</strong> from list.</span>
          <button
            onClick={handleUndoRemove}
            className="text-amber-400 hover:text-white underline ml-3 uppercase tracking-widest font-mono"
          >
            Undo Removal
          </button>
        </div>
      )}

      {/* Top Banner: CUJ Task 2 Align Items with Total Budget */}
      <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-8 mb-8">
        <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
          
          {/* Left info */}
          <div className="space-y-2">
            <span className="text-[10px] font-bold tracking-[0.25em] text-[#8B2131] uppercase block">
              02. Live Inventory & Budget Matrix
            </span>
            <h1 className="text-3xl sm:text-5xl font-black tracking-tighter uppercase leading-none text-[#1A1A1A]">
              Curated CymbalMart Cart
            </h1>
            <p className="text-xs sm:text-sm text-[#1A1A1A]/70 max-w-2xl font-medium leading-relaxed pt-1">
              {plan.summaryNotes}
            </p>
          </div>

          {/* Quick action buttons */}
          <div className="flex items-center space-x-3 self-start">
            <button
              id="open-portion-guide-btn"
              onClick={() => setIsPortionModalOpen(true)}
              className="inline-flex items-center space-x-2 px-4 py-2.5 border border-[#1A1A1A]/20 bg-[#F9F8F3] hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A] text-[10px] font-bold uppercase tracking-wider transition-colors"
            >
              <Info className="w-3.5 h-3.5 text-[#8B2131]" />
              <span>Portion Rules ({totalGuests} Guests)</span>
            </button>
            <button
              id="open-add-custom-item-btn"
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center space-x-1.5 px-4 py-2.5 bg-[#1A1A1A] hover:bg-[#8B2131] text-white text-[10px] font-bold uppercase tracking-widest transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Custom Item</span>
            </button>
          </div>

        </div>

        {/* Real-time Budget Health Meter */}
        <div className="mt-8 pt-8 border-t border-[#1A1A1A]/10 grid grid-cols-1 md:grid-cols-4 gap-6 items-center">
          
          {/* Progress Bar & Variance */}
          <div className="md:col-span-2 space-y-2.5">
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider">
              <span className="text-[#1A1A1A]">Budget Matrix Allocation</span>
              <span className={isOverBudget ? 'text-[#8B2131] font-mono' : 'text-[#1A1A1A] font-mono'}>
                ${currentTotal.toFixed(2)} / ${targetBudget.toFixed(2)} ({budgetPercentage}%)
              </span>
            </div>
            <div className="w-full bg-[#1A1A1A]/10 h-2 overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  isOverBudget
                    ? 'bg-[#8B2131]'
                    : budgetPercentage > 90
                    ? 'bg-amber-600'
                    : 'bg-[#1A1A1A]'
                }`}
                style={{ width: `${Math.min(100, budgetPercentage)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono uppercase text-[#1A1A1A]/60">
              <span>$0.00</span>
              <span>
                {isOverBudget ? (
                  <span className="text-[#8B2131] font-bold flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    Over by ${Math.abs(budgetVariance).toFixed(2)}
                  </span>
                ) : (
                  <span className="text-[#1A1A1A] font-bold flex items-center">
                    <ShieldCheck className="w-3 h-3 mr-1 text-[#8B2131]" />
                    ${budgetVariance.toFixed(2)} Buffer Remaining
                  </span>
                )}
              </span>
              <span>Cap: ${targetBudget}.00</span>
            </div>
          </div>

          {/* Cost Per Guest */}
          <div className="p-4 border border-[#1A1A1A]/10 bg-[#F9F8F3] text-center">
            <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A]/60 block mb-0.5">Cost Per Guest</span>
            <span className="text-3xl font-black font-mono text-[#1A1A1A]">${costPerGuest}</span>
            <span className="text-[9px] font-mono text-[#1A1A1A]/50 uppercase block mt-0.5">{totalGuests} attendees ({config.durationHours}h)</span>
          </div>

          {/* Auto Align or Status Action */}
          <div className="flex flex-col justify-center">
            {isOverBudget ? (
              <button
                id="auto-align-budget-btn"
                onClick={handleAutoAlignBudget}
                className="w-full py-3 px-4 bg-[#8B2131] hover:bg-[#1A1A1A] text-white font-bold text-[10px] uppercase tracking-widest flex items-center justify-center space-x-1.5 transition-colors"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Auto-Align to Budget</span>
              </button>
            ) : (
              <div className="p-3.5 border border-[#1A1A1A]/10 bg-[#F1F0EA] text-[#1A1A1A] text-[10px] font-bold uppercase tracking-wider text-center">
                ✓ Budget Synchronized
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Category Tabs and Filter Toolbar */}
      <div className="space-y-4 mb-6">
        
        {/* Category Tabs Horizontal Scroll */}
        <div className="flex items-center space-x-1 overflow-x-auto pb-2 scrollbar-none border-b border-[#1A1A1A]/10">
          <button
            id="cat-tab-all"
            onClick={() => setSelectedCategory('all')}
            className={`px-4 py-2 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-all ${
              selectedCategory === 'all'
                ? 'bg-[#1A1A1A] text-white'
                : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F1F0EA]'
            }`}
          >
            All Items ({plan.items.length})
          </button>

          {Object.entries(CATEGORIES).map(([catKey, catMeta]) => {
            const isSelected = selectedCategory === catKey;
            const sub = categorySubtotals[catKey] || { count: 0, subtotal: 0 };
            return (
              <button
                key={catKey}
                id={`cat-tab-${catKey}`}
                onClick={() => setSelectedCategory(catKey as CategoryType)}
                className={`px-3.5 py-2 text-[10px] font-bold uppercase tracking-wider whitespace-nowrap transition-all flex items-center space-x-1.5 ${
                  isSelected
                    ? 'bg-[#1A1A1A] text-white'
                    : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F1F0EA]'
                }`}
              >
                <span>{catMeta.label}</span>
                <span className={`text-[9px] font-mono px-1.5 py-0.2 ${
                  isSelected ? 'bg-[#8B2131] text-white' : 'bg-[#1A1A1A]/10 text-[#1A1A1A]'
                }`}>
                  ${sub.subtotal.toFixed(0)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 border border-[#1A1A1A]/10">
          <div className="relative w-full sm:w-80">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-[#1A1A1A]/40" />
            <input
              id="search-items-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="SEARCH GROCERY / BRAND / DIETARY..."
              className="w-full pl-9 pr-3 py-1.5 text-xs font-mono rounded-none border border-[#1A1A1A]/20 bg-[#F9F8F3] focus:outline-hidden focus:border-[#1A1A1A]"
            />
          </div>

          <div className="flex items-center space-x-4 w-full sm:w-auto justify-end">
            <label className="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] cursor-pointer">
              <input
                id="filter-must-have-toggle"
                type="checkbox"
                checked={filterMustHaveOnly}
                onChange={(e) => setFilterMustHaveOnly(e.target.checked)}
                className="w-3.5 h-3.5 accent-[#1A1A1A]"
              />
              <span>Essentials Only</span>
            </label>
            <span className="text-[10px] font-mono uppercase text-[#1A1A1A]/40">
              Showing {filteredItems.length} of {plan.items.length}
            </span>
          </div>
        </div>

      </div>

      {/* Shopping List Items Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white border border-[#1A1A1A]/10 p-12 text-center">
          <Layers className="w-10 h-10 text-[#1A1A1A]/30 mx-auto mb-3" />
          <h3 className="text-sm font-bold uppercase tracking-widest text-[#1A1A1A]">No items match your filter</h3>
          <p className="text-xs text-[#1A1A1A]/50 mt-1">Try resetting search or adding a custom item.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setFilterMustHaveOnly(false);
            }}
            className="mt-4 px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-white bg-[#1A1A1A] hover:bg-[#8B2131]"
          >
            Clear Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item, idx) => {
            const itemTotal = item.unitPrice * item.quantity;
            const isSignature = item.tier === 'signature' || item.brand.includes('CymbalMart');

            return (
              <div
                key={item.id}
                id={`item-card-${item.id}`}
                className="bg-white border border-[#1A1A1A]/10 hover:border-[#1A1A1A]/40 p-5 flex flex-col justify-between transition-all group"
              >
                {/* Card Top: Brand Badge & Category */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-mono font-bold text-[#1A1A1A]/40">
                      #{String(idx + 1).padStart(2, '0')}
                    </span>

                    <div className="flex items-center space-x-1.5">
                      <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 ${
                        isSignature
                          ? 'bg-[#1A1A1A] text-white'
                          : item.tier === 'fresh'
                          ? 'bg-[#8B2131] text-white'
                          : 'bg-[#F1F0EA] text-[#1A1A1A] border border-[#1A1A1A]/15'
                      }`}>
                        {item.brand}
                      </span>

                      <button
                        id={`must-have-toggle-${item.id}`}
                        onClick={() => handleToggleMustHave(item.id)}
                        title="Toggle Essential / Optional"
                        className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 border transition-colors ${
                          item.isMustHave
                            ? 'border-[#8B2131] text-[#8B2131] bg-[#8B2131]/5'
                            : 'border-[#1A1A1A]/20 text-[#1A1A1A]/40 hover:text-[#1A1A1A]'
                        }`}
                      >
                        {item.isMustHave ? 'Needed' : 'Optional'}
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold uppercase text-[#1A1A1A] text-sm leading-snug tracking-tight">
                    {item.name}
                  </h3>

                  <div className="mt-1 flex items-center space-x-2 text-xs font-mono text-[#1A1A1A]/60">
                    <span>{item.unitSize}</span>
                    <span>•</span>
                    <span className="font-bold text-[#1A1A1A]">${item.unitPrice.toFixed(2)}/ea</span>
                  </div>

                  {/* Dietary Tags */}
                  {item.dietaryTags.length > 0 && (
                    <div className="mt-2.5 flex flex-wrap gap-1">
                      {item.dietaryTags.map((tag, i) => (
                        <span
                          key={i}
                          className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 bg-[#F1F0EA] text-[#1A1A1A]/70"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Alternative Brand Swap Recommendation */}
                  {item.alternativeOption && (
                    <div className="mt-3 p-2.5 bg-[#8B2131]/5 border-l-2 border-[#8B2131] text-xs flex items-center justify-between">
                      <div className="truncate pr-2">
                        <span className="text-[9px] font-bold uppercase tracking-wider text-[#8B2131] block">Tier Alternative</span>
                        <span className="font-medium text-[#1A1A1A] text-xs truncate block">
                          {item.alternativeOption.name} (${item.alternativeOption.unitPrice.toFixed(2)})
                        </span>
                      </div>
                      <button
                        id={`swap-btn-${item.id}`}
                        onClick={() => handleSwapAlternative(item)}
                        className="px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-white bg-[#1A1A1A] hover:bg-[#8B2131] whitespace-nowrap transition-colors"
                      >
                        Swap
                      </button>
                    </div>
                  )}
                </div>

                {/* Card Bottom: Quantity & Total */}
                <div className="mt-4 pt-3 border-t border-[#1A1A1A]/10 flex items-center justify-between">
                  {/* Stepper with editable input */}
                  <div className="flex items-center space-x-1.5">
                    <button
                      id={`item-minus-${item.id}`}
                      onClick={() => handleQuantityChange(item.id, -1)}
                      className="w-7 h-7 border border-[#1A1A1A]/30 bg-white hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A] font-bold flex items-center justify-center text-xs transition-colors cursor-pointer"
                    >
                      -
                    </button>
                    <input
                      id={`item-qty-input-${item.id}`}
                      type="number"
                      min="1"
                      max="99"
                      value={item.quantity}
                      onChange={(e) => handleDirectQuantitySet(item.id, parseInt(e.target.value, 10))}
                      className="w-10 h-7 text-center font-mono font-black text-xs border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                    />
                    <button
                      id={`item-plus-${item.id}`}
                      onClick={() => handleQuantityChange(item.id, 1)}
                      className="w-7 h-7 border border-[#1A1A1A]/30 bg-white hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A] font-bold flex items-center justify-center text-xs transition-colors cursor-pointer"
                    >
                      +
                    </button>
                  </div>

                  {/* Price & Delete */}
                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <span className="font-mono font-black text-base text-[#1A1A1A] block leading-none">
                        ${itemTotal.toFixed(2)}
                      </span>
                      <span className="text-[9px] font-mono text-[#1A1A1A]/50 block">
                        (${item.unitPrice.toFixed(2)} ea)
                      </span>
                    </div>
                    <button
                      id={`delete-item-${item.id}`}
                      onClick={() => handleRemoveItem(item.id)}
                      title="Remove item from list"
                      className="text-[#1A1A1A]/30 hover:text-[#8B2131] transition-colors p-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Floating Bottom Action Bar */}
      <div className="sticky bottom-4 z-30 mt-12">
        <div className="max-w-4xl mx-auto bg-[#1A1A1A] text-white p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 border border-[#1A1A1A] shadow-2xl">
          <div className="flex items-center space-x-4">
            <div className="text-3xl font-black font-mono text-white leading-none">
              ${currentTotal.toFixed(2)}
            </div>
            <div className="border-l border-white/20 pl-4">
              <div className="flex items-center space-x-2">
                <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">
                  Cart Total
                </span>
                <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.2 ${
                  isOverBudget ? 'bg-[#8B2131] text-white' : 'bg-emerald-700 text-white'
                }`}>
                  {isOverBudget ? `+$${Math.abs(budgetVariance).toFixed(2)} OVER` : `$${budgetVariance.toFixed(2)} BUFFER`}
                </span>
              </div>
              <p className="text-[11px] font-mono text-white/50">
                {plan.items.length} items • {totalGuests} guests (${costPerGuest}/person)
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
            <button
              id="back-to-define-btn"
              onClick={onBackToDefine}
              className="px-4 py-2.5 text-[10px] font-bold uppercase tracking-widest text-white/70 hover:text-white hover:bg-white/10 transition-colors"
            >
              ← Edit Event Info
            </button>

            <button
              id="proceed-to-refine-btn"
              onClick={onProceedToCheckout}
              className="px-6 py-3 bg-white hover:bg-[#8B2131] hover:text-white text-[#1A1A1A] text-[10px] font-black uppercase tracking-[0.2em] flex items-center justify-center space-x-2 transition-colors"
            >
              <span>Task 3: Refine & Checkout</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AddCustomItemModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddItem={handleAddCustomItem}
      />

      <PortionGuideModal
        isOpen={isPortionModalOpen}
        onClose={() => setIsPortionModalOpen(false)}
        analysis={plan.portionAnalysis}
        totalGuests={totalGuests}
        durationHours={config.durationHours}
      />

    </div>
  );
};

