import React from 'react';
import { ShoppingBag, Sparkles, DollarSign, Users, RotateCcw, ArrowRight, Mic } from 'lucide-react';
import { PartyPlan, EventConfig } from '../types/party';

interface NavbarProps {
  currentStep: number;
  onStepClick: (step: number) => void;
  plan: PartyPlan | null;
  config: EventConfig;
  onReset: () => void;
  isListening?: boolean;
  onToggleListening?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentStep,
  onStepClick,
  plan,
  config,
  onReset,
  isListening = false,
  onToggleListening
}) => {
  const totalGuests = (config.guestCount.adults || 0) + (config.guestCount.kids || 0) || 1;
  const currentTotal = plan?.totalEstimatedCost || 0;
  const targetBudget = config.budget || 0;
  const isOverBudget = plan ? currentTotal > targetBudget : false;

  return (
    <header className="sticky top-0 z-40 bg-[#F9F8F3]/95 backdrop-blur-md border-b border-[#1A1A1A]/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo and Brand */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group" 
            onClick={() => onStepClick(1)}
          >
            <div className="w-10 h-10 bg-[#1A1A1A] text-white flex items-center justify-center font-black text-lg tracking-tighter group-hover:bg-[#8B2131] transition-colors">
              CM
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-black text-xl tracking-tighter uppercase text-[#1A1A1A]">
                  Cymbal<span className="text-[#8B2131]">Mart</span>
                </span>
                <span className="hidden sm:inline-block px-2.5 py-0.5 text-[9px] font-bold tracking-widest uppercase bg-[#1A1A1A] text-white rounded-full">
                  Shopping Agent
                </span>
              </div>
              <p className="text-[10px] font-bold tracking-[0.15em] uppercase text-[#1A1A1A]/50 hidden md:block">
                Event Planning & Grocery Matrix
              </p>
            </div>
          </div>

          {/* Stepper Navigation */}
          <nav className="hidden lg:flex items-center space-x-1 border border-[#1A1A1A]/10 bg-white p-1">
            <button
              id="nav-step-1-btn"
              onClick={() => onStepClick(1)}
              className={`flex items-center space-x-2 px-4 py-2 text-[11px] font-bold uppercase tracking-wider transition-all ${
                currentStep === 1
                  ? 'bg-[#1A1A1A] text-white'
                  : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F1F0EA]'
              }`}
            >
              <span className="text-[9px] opacity-60">01</span>
              <span>Define Event</span>
            </button>

            <span className="text-[#1A1A1A]/20 px-1 font-mono">/</span>

            <button
              id="nav-step-2-btn"
              onClick={() => plan && onStepClick(2)}
              disabled={!plan}
              className={`flex items-center space-x-2 px-4 py-2 text-[11px] font-bold uppercase tracking-wider transition-all ${
                currentStep === 2
                  ? 'bg-[#1A1A1A] text-white'
                  : plan
                  ? 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F1F0EA]'
                  : 'text-[#1A1A1A]/30 cursor-not-allowed opacity-50'
              }`}
            >
              <span className="text-[9px] opacity-60">02</span>
              <span>Review List</span>
            </button>

            <span className="text-[#1A1A1A]/20 px-1 font-mono">/</span>

            <button
              id="nav-step-3-btn"
              onClick={() => plan && onStepClick(3)}
              disabled={!plan}
              className={`flex items-center space-x-2 px-4 py-2 text-[11px] font-bold uppercase tracking-wider transition-all ${
                currentStep === 3
                  ? 'bg-[#1A1A1A] text-white'
                  : plan
                  ? 'text-[#1A1A1A]/70 hover:text-[#1A1A1A] hover:bg-[#F1F0EA]'
                  : 'text-[#1A1A1A]/30 cursor-not-allowed opacity-50'
              }`}
            >
              <span className="text-[9px] opacity-60">03</span>
              <span>Refine & Checkout</span>
            </button>
          </nav>

          {/* Right Status & Actions */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {plan && (
              <div className="hidden sm:flex items-center space-x-3 px-3.5 py-1.5 border border-[#1A1A1A]/15 bg-white text-xs">
                <div className="flex items-center text-[#1A1A1A]/70 text-[11px] font-bold uppercase tracking-wider">
                  <Users className="w-3.5 h-3.5 mr-1 text-[#8B2131]" />
                  <span>{totalGuests} GUESTS</span>
                </div>
                <span className="text-[#1A1A1A]/20 font-mono">|</span>
                <div className="flex items-center font-mono font-bold text-xs">
                  <span className={isOverBudget ? 'text-[#8B2131]' : 'text-[#1A1A1A]'}>
                    ${currentTotal.toFixed(2)}
                  </span>
                  <span className="text-[#1A1A1A]/40 font-normal ml-1">/ ${targetBudget}</span>
                </div>
              </div>
            )}

            {/* Hands-Free Voice Control Toggle */}
            {onToggleListening && (
              <button
                id="navbar-voice-toggle-btn"
                onClick={onToggleListening}
                title={isListening ? 'Hands-Free Voice is Active (Click to mute)' : 'Activate Hands-Free Voice Control'}
                className={`flex items-center space-x-1.5 px-3 py-2 text-[10px] font-black uppercase tracking-wider border transition-all cursor-pointer ${
                  isListening
                    ? 'bg-[#8B2131] text-white border-[#8B2131] animate-pulse'
                    : 'bg-white text-[#1A1A1A] border-[#1A1A1A]/20 hover:border-[#1A1A1A] hover:bg-[#F1F0EA]'
                }`}
              >
                <Mic className={`w-3.5 h-3.5 ${isListening ? 'text-amber-300' : 'text-[#8B2131]'}`} />
                <span className="hidden md:inline">{isListening ? 'Voice: Live' : 'Voice'}</span>
              </button>
            )}

            {plan && (
              <button
                id="reset-plan-btn"
                onClick={onReset}
                title="Start a new party plan"
                className="p-2.5 border border-[#1A1A1A]/20 bg-white text-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}

            {currentStep !== 3 && plan && (
              <button
                id="header-checkout-btn"
                onClick={() => onStepClick(3)}
                className="inline-flex items-center px-4 py-2.5 bg-[#1A1A1A] hover:bg-[#8B2131] text-white text-[10px] font-bold uppercase tracking-widest transition-colors"
              >
                <ShoppingBag className="w-3.5 h-3.5 mr-1.5" />
                <span>Checkout</span>
              </button>
            )}
          </div>

        </div>
      </div>
    </header>
  );
};

