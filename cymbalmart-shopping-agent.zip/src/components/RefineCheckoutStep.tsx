import React, { useState } from 'react';
import { 
  Sparkles, 
  Send, 
  DollarSign, 
  ShoppingBag, 
  MapPin, 
  Clock, 
  Users, 
  UserCheck, 
  Share2, 
  Check, 
  ShieldCheck, 
  Zap, 
  ArrowLeft, 
  Car, 
  Truck, 
  CheckCircle,
  HelpCircle,
  Tag
} from 'lucide-react';
import { PartyPlan, EventConfig, FulfillmentDetails, ShoppingItem } from '../types/party';
import { CYMBALMART_STORES, PICKUP_TIME_SLOTS } from '../data/cymbalmartData';
import { OrderConfirmationModal } from './OrderConfirmationModal';

interface RefineCheckoutStepProps {
  plan: PartyPlan;
  config: EventConfig;
  onUpdatePlan: (newPlan: PartyPlan) => void;
  onRefineWithAI: (prompt: string) => Promise<void>;
  isRefining: boolean;
  onBackToReview: () => void;
  refinementHistory: Array<{ prompt: string; explanation: string }>;
}

export const RefineCheckoutStep: React.FC<RefineCheckoutStepProps> = ({
  plan,
  config,
  onUpdatePlan,
  onRefineWithAI,
  isRefining,
  onBackToReview,
  refinementHistory
}) => {
  const [customPrompt, setCustomPrompt] = useState('');
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [generatedOrderNumber, setGeneratedOrderNumber] = useState('');
  const [copiedShareLink, setCopiedShareLink] = useState(false);

  // Guest assignment state: map of itemId -> guest name
  const [assignedGuests, setAssignedGuests] = useState<Record<string, string>>({});
  const [excludeAssignedFromCart, setExcludeAssignedFromCart] = useState(true);

  // Fulfillment form state
  const [fulfillment, setFulfillment] = useState<FulfillmentDetails>({
    method: 'pickup',
    storeId: CYMBALMART_STORES[0].id,
    date: 'Today',
    timeSlot: PICKUP_TIME_SLOTS[1],
    vehicleDescription: 'Silver SUV',
    deliveryAddress: '123 Meadow Lane, Apt 4B',
    driverInstructions: 'Leave at front porch near side gate',
    contactPhone: '(555) 234-5678',
    contactName: 'Alex Johnson'
  });

  const totalGuests = (config.guestCount.adults || 0) + (config.guestCount.kids || 0) || 1;
  const targetBudget = config.budget;

  // Active items for checkout (excluding guest-assigned items if host toggled it)
  const checkoutItems = plan.items.filter((item) => {
    if (excludeAssignedFromCart && assignedGuests[item.id]) {
      return false;
    }
    return true;
  });

  const subtotal = checkoutItems.reduce((acc, it) => acc + it.unitPrice * it.quantity, 0);
  const memberDiscount = subtotal > 50 ? +(subtotal * 0.08).toFixed(2) : 0;
  const estimatedTax = +(subtotal * 0.025).toFixed(2); // low tax rate on mixed grocery/supplies
  const finalTotal = +(subtotal - memberDiscount + estimatedTax).toFixed(2);

  const guestSavings = plan.items
    .filter((it) => assignedGuests[it.id])
    .reduce((acc, it) => acc + it.unitPrice * it.quantity, 0);

  const QUICK_PROMPTS = [
    { label: '⚡ Trim $30 to stay strictly under budget', prompt: 'Make this plan $30 cheaper by swapping brand items for CymbalMart Signature or reducing non-essential tableware.' },
    { label: '🥗 100% Vegetarian & Plant-Based', prompt: 'Swap all meat mains and snacks for hearty, top-rated plant-based burger patties and vegetarian dips.' },
    { label: '🍹 Artisan Mocktail & Punch Bar', prompt: 'Replace all sodas with fresh citrus garnishes, craft sparkling botanical mixers, and an infused party punch recipe.' },
    { label: '👶 Add Kid Crafts & Fun Snacks', prompt: 'Add kid-friendly fruit pouches, mini juice boxes, and simple party crafts.' },
    { label: '♻️ 100% Compostable Eco Tableware', prompt: 'Ensure all plates, cups, and utensils are certified 100% compostable plant fiber.' }
  ];

  const handleQuickPromptClick = (prompt: string) => {
    onRefineWithAI(prompt);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim() || isRefining) return;
    onRefineWithAI(customPrompt.trim());
    setCustomPrompt('');
  };

  const handleAssignGuest = (itemId: string, guestName: string) => {
    setAssignedGuests((prev) => {
      const copy = { ...prev };
      if (!guestName.trim()) {
        delete copy[itemId];
      } else {
        copy[itemId] = guestName.trim();
      }
      return copy;
    });
  };

  const handleCopyGuestLink = () => {
    setCopiedShareLink(true);
    setTimeout(() => setCopiedShareLink(false), 3000);
  };

  const handlePlaceOrder = () => {
    const randomId = `CM-PARTY-${Math.floor(100000 + Math.random() * 900000)}`;
    setGeneratedOrderNumber(randomId);
    setIsConfirmationOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 text-left">
      
      {/* Step Header */}
      <div className="mb-8">
        <span className="text-[10px] font-bold tracking-[0.25em] text-[#8B2131] uppercase mb-1.5 block">
          03. Refine Constraints & Finalize Order
        </span>
        <h1 className="text-3xl sm:text-5xl font-black tracking-tighter uppercase leading-none text-[#1A1A1A]">
          Adjust Logistics & Finalize Plan
        </h1>
        <p className="text-xs sm:text-sm text-[#1A1A1A]/70 font-medium mt-1.5 max-w-3xl">
          Use the AI assistant to calibrate dietary constraints, coordinate potluck assignments with guests, schedule your CymbalMart curbside pickup or delivery bay, and finalize your party.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: AI Refiner & Guest Coordination (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* AI Refinement Module */}
          <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-7 space-y-5">
            <div className="flex items-center space-x-3 pb-3 border-b border-[#1A1A1A]/10">
              <div className="w-8 h-8 bg-[#1A1A1A] text-white flex items-center justify-center font-bold">
                <Sparkles className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider text-[#1A1A1A]">AI Plan Refiner & Constraint Engine</h2>
                <p className="text-[11px] text-[#1A1A1A]/60">Instruct Gemini to calibrate prices, dietary restrictions, or menu scale</p>
              </div>
            </div>

            {/* Quick Prompt Chips */}
            <div>
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#8B2131] block mb-2">
                Quick Adjustments:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {QUICK_PROMPTS.map((qp, idx) => (
                  <button
                    key={idx}
                    id={`quick-prompt-${idx}`}
                    disabled={isRefining}
                    onClick={() => handleQuickPromptClick(qp.prompt)}
                    className="text-[10px] font-bold uppercase tracking-wider px-3 py-1.5 border border-[#1A1A1A]/20 bg-[#F9F8F3] hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A] transition-colors disabled:opacity-50"
                  >
                    {qp.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Natural language input */}
            <form onSubmit={handleCustomSubmit} className="relative">
              <input
                id="refine-prompt-input"
                type="text"
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                disabled={isRefining}
                placeholder="Ask AI: e.g. 'Add homemade guacamole ingredients' or 'Reduce ice by 5 lbs'..."
                className="w-full pl-4 pr-12 py-3 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A] disabled:bg-slate-100"
              />
              <button
                id="submit-refine-btn"
                type="submit"
                disabled={!customPrompt.trim() || isRefining}
                className="absolute right-2 top-2 p-2 bg-[#1A1A1A] text-white hover:bg-[#8B2131] disabled:opacity-50 transition-colors"
              >
                {isRefining ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </button>
            </form>

            {/* Refinement History Feed */}
            {refinementHistory.length > 0 && (
              <div className="mt-4 pt-4 border-t border-[#1A1A1A]/10 space-y-2.5">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#1A1A1A]/50 block">
                  Recent AI Adjustments:
                </span>
                {refinementHistory.map((hist, idx) => (
                  <div key={idx} className="p-3 bg-[#F9F8F3] border-l-2 border-[#8B2131] text-xs">
                    <p className="font-bold uppercase text-[11px] text-[#1A1A1A]">"{hist.prompt}"</p>
                    <p className="text-[#1A1A1A]/70 mt-1 leading-relaxed">{hist.explanation}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Guest Potluck & Grocery Coordinator */}
          <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-7 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1A1A1A]/10">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#1A1A1A] text-white flex items-center justify-center font-bold">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                </div>
                <div>
                  <h2 className="text-sm font-bold uppercase tracking-wider text-[#1A1A1A]">Guest Contribution Coordinator</h2>
                  <p className="text-[11px] text-[#1A1A1A]/60">Assign grocery items to guests (ice, sodas, chips) to reduce host cost</p>
                </div>
              </div>

              <button
                id="copy-guest-link-btn"
                onClick={handleCopyGuestLink}
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-[#1A1A1A] hover:bg-[#8B2131] text-white text-[10px] font-bold uppercase tracking-widest transition-colors self-start sm:self-auto"
              >
                {copiedShareLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copiedShareLink ? 'Link Copied!' : 'Share Guest Link'}</span>
              </button>
            </div>

            {/* List of items that can be assigned */}
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {plan.items.slice(0, 6).map((item) => {
                const assigned = assignedGuests[item.id] || '';
                return (
                  <div
                    key={item.id}
                    className="p-3 border border-[#1A1A1A]/10 bg-[#F9F8F3] flex items-center justify-between text-xs"
                  >
                    <div className="truncate pr-2">
                      <span className="font-bold uppercase text-xs text-[#1A1A1A] truncate block">{item.name}</span>
                      <span className="text-[#1A1A1A]/50 font-mono text-[10px]">{item.quantity}x @ ${item.unitPrice.toFixed(2)} (${(item.quantity * item.unitPrice).toFixed(2)})</span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        id={`assign-input-${item.id}`}
                        type="text"
                        placeholder="Guest Name..."
                        value={assigned}
                        onChange={(e) => handleAssignGuest(item.id, e.target.value)}
                        className="w-28 sm:w-36 px-2.5 py-1 text-xs font-mono border border-[#1A1A1A]/20 bg-white focus:outline-hidden focus:border-[#1A1A1A]"
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Deduct toggle */}
            {guestSavings > 0 && (
              <div className="p-3.5 bg-[#8B2131]/5 border-l-4 border-[#8B2131] flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold uppercase text-[11px] text-[#8B2131] block">
                    Guest Contributions: -${guestSavings.toFixed(2)} saved!
                  </span>
                  <span className="text-[#1A1A1A]/70 text-[10px] font-mono">
                    Assigned: {Object.values(assignedGuests).filter(Boolean).join(', ')}
                  </span>
                </div>
                <label className="flex items-center space-x-2 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] cursor-pointer">
                  <input
                    id="deduct-guest-toggle"
                    type="checkbox"
                    checked={excludeAssignedFromCart}
                    onChange={(e) => setExcludeAssignedFromCart(e.target.checked)}
                    className="w-3.5 h-3.5 accent-[#1A1A1A]"
                  />
                  <span>Deduct from Checkout</span>
                </label>
              </div>
            )}
          </div>

          {/* Party Run-of-Show Prep Tips */}
          <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-7 space-y-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#1A1A1A] flex items-center space-x-2">
              <Clock className="w-4 h-4 text-[#8B2131]" />
              <span>Recommended Party Run-of-Show Timeline</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {plan.partyPrepTips.map((tip, idx) => (
                <div key={idx} className="p-3.5 border border-[#1A1A1A]/10 bg-[#F9F8F3] text-xs">
                  <span className="font-bold text-[#8B2131] uppercase tracking-widest text-[9px] block mb-1 font-mono">
                    {tip.timeframe}
                  </span>
                  <p className="text-[#1A1A1A]/80 leading-relaxed font-medium">{tip.task}</p>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Fulfillment & Checkout Order Summary (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Fulfillment Configuration Card */}
          <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-7 space-y-5">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#1A1A1A] flex items-center space-x-2 pb-2 border-b border-[#1A1A1A]/10">
              <ShoppingBag className="w-4 h-4 text-[#8B2131]" />
              <span>CymbalMart Grocery Fulfillment</span>
            </h2>

            {/* Method Tabs */}
            <div className="grid grid-cols-2 gap-1 p-1 bg-[#F1F0EA] border border-[#1A1A1A]/10">
              <button
                id="fulfillment-pickup-btn"
                type="button"
                onClick={() => setFulfillment({ ...fulfillment, method: 'pickup' })}
                className={`py-2.5 px-3 text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-all ${
                  fulfillment.method === 'pickup'
                    ? 'bg-[#1A1A1A] text-white'
                    : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
                }`}
              >
                <Car className="w-3.5 h-3.5" />
                <span>Curbside (Free)</span>
              </button>

              <button
                id="fulfillment-delivery-btn"
                type="button"
                onClick={() => setFulfillment({ ...fulfillment, method: 'delivery' })}
                className={`py-2.5 px-3 text-[10px] font-bold uppercase tracking-wider flex items-center justify-center space-x-1.5 transition-all ${
                  fulfillment.method === 'delivery'
                    ? 'bg-[#1A1A1A] text-white'
                    : 'text-[#1A1A1A]/70 hover:text-[#1A1A1A]'
                }`}
              >
                <Truck className="w-3.5 h-3.5" />
                <span>Local Delivery</span>
              </button>
            </div>

            {/* Store or Address selection */}
            {fulfillment.method === 'pickup' ? (
              <div className="space-y-3">
                <div>
                  <label htmlFor="select-store-loc" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                    Select CymbalMart Store
                  </label>
                  <select
                    id="select-store-loc"
                    value={fulfillment.storeId}
                    onChange={(e) => setFulfillment({ ...fulfillment, storeId: e.target.value })}
                    className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                  >
                    {CYMBALMART_STORES.map((store) => (
                      <option key={store.id} value={store.id}>
                        {store.name} ({store.distance})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="vehicle-desc-input" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                    Vehicle Info (for Curbside Bay Loading)
                  </label>
                  <input
                    id="vehicle-desc-input"
                    type="text"
                    value={fulfillment.vehicleDescription}
                    onChange={(e) => setFulfillment({ ...fulfillment, vehicleDescription: e.target.value })}
                    placeholder="e.g. Silver Honda CRV / Blue Tesla"
                    className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div>
                  <label htmlFor="delivery-address-input" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                    Delivery Address
                  </label>
                  <input
                    id="delivery-address-input"
                    type="text"
                    value={fulfillment.deliveryAddress}
                    onChange={(e) => setFulfillment({ ...fulfillment, deliveryAddress: e.target.value })}
                    placeholder="Street address, unit/apt"
                    className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                  />
                </div>
              </div>
            )}

            {/* Time Slot Picker */}
            <div>
              <label htmlFor="select-time-slot" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Preferred Loading Window
              </label>
              <select
                id="select-time-slot"
                value={fulfillment.timeSlot}
                onChange={(e) => setFulfillment({ ...fulfillment, timeSlot: e.target.value })}
                className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              >
                {PICKUP_TIME_SLOTS.map((slot, i) => (
                  <option key={i} value={slot}>{slot}</option>
                ))}
              </select>
            </div>

            {/* Host Contact Info */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <label htmlFor="contact-name-input" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                  Host Name
                </label>
                <input
                  id="contact-name-input"
                  type="text"
                  value={fulfillment.contactName}
                  onChange={(e) => setFulfillment({ ...fulfillment, contactName: e.target.value })}
                  className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                />
              </div>
              <div>
                <label htmlFor="contact-phone-input" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                  Phone (for SMS)
                </label>
                <input
                  id="contact-phone-input"
                  type="tel"
                  value={fulfillment.contactPhone}
                  onChange={(e) => setFulfillment({ ...fulfillment, contactPhone: e.target.value })}
                  className="w-full px-3 py-2 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
                />
              </div>
            </div>
          </div>

          {/* Itemized Order Checkout Card */}
          <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-7 space-y-4">
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#8B2131] block">
              Order Manifest
            </span>
            <h2 className="text-xl font-black uppercase tracking-tight text-[#1A1A1A]">
              Budget Finalization
            </h2>

            <div className="space-y-2.5 text-xs font-mono">
              <div className="flex justify-between text-[#1A1A1A]/70">
                <span>Items Subtotal ({checkoutItems.length} SKUs)</span>
                <span className="font-bold text-[#1A1A1A]">${subtotal.toFixed(2)}</span>
              </div>

              {memberDiscount > 0 && (
                <div className="flex justify-between text-emerald-700 font-bold">
                  <span>CymbalMart Member Savings (8%)</span>
                  <span>-${memberDiscount.toFixed(2)}</span>
                </div>
              )}

              {guestSavings > 0 && excludeAssignedFromCart && (
                <div className="flex justify-between text-[#8B2131] font-bold">
                  <span>Guest Assigned Deductions</span>
                  <span>-${guestSavings.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between text-[#1A1A1A]/70">
                <span>Fulfillment ({fulfillment.method === 'pickup' ? 'Curbside' : 'Delivery'})</span>
                <span className="font-bold text-emerald-700">FREE</span>
              </div>

              <div className="flex justify-between text-[#1A1A1A]/70">
                <span>Estimated Local Tax</span>
                <span className="font-bold text-[#1A1A1A]">${estimatedTax.toFixed(2)}</span>
              </div>

              <div className="border-b border-[#1A1A1A]/10 my-3" />

              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#8B2131] block">Final Payable Total</span>
                <div className="text-4xl font-black font-mono leading-none tracking-tight text-[#1A1A1A] mt-1">
                  ${finalTotal.toFixed(2)}
                </div>
              </div>

              <div className="flex items-center justify-between text-[10px] text-[#1A1A1A]/60 pt-1 font-mono uppercase">
                <span>Target: ${targetBudget.toFixed(2)}</span>
                <span className={finalTotal <= targetBudget ? 'text-emerald-700 font-bold' : 'text-[#8B2131] font-bold'}>
                  {finalTotal <= targetBudget
                    ? `✓ $${(targetBudget - finalTotal).toFixed(2)} UNDER`
                    : `⚠️ $${(finalTotal - targetBudget).toFixed(2)} OVER`}
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 space-y-2">
              <button
                id="place-cymbalmart-order-btn"
                type="button"
                onClick={handlePlaceOrder}
                className="w-full py-4 px-4 bg-[#1A1A1A] hover:bg-[#8B2131] text-white font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center space-x-2 transition-colors cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Place Order & Finalize Party</span>
              </button>

              <button
                id="back-to-review-list-btn"
                type="button"
                onClick={onBackToReview}
                className="w-full py-2.5 px-3 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] flex items-center justify-center space-x-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Review & Adjust List</span>
              </button>
            </div>
          </div>

        </div>

      </div>

      {/* Confirmation Modal */}
      <OrderConfirmationModal
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        plan={plan}
        config={config}
        fulfillment={fulfillment}
        orderNumber={generatedOrderNumber}
      />

    </div>
  );
};
