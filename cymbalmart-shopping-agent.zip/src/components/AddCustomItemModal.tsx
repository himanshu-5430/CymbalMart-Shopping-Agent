import React, { useState } from 'react';
import { X, Plus, Tag } from 'lucide-react';
import { ShoppingItem, CategoryType, BrandTier } from '../types/party';
import { CATEGORIES } from '../data/cymbalmartData';

interface AddCustomItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddItem: (item: ShoppingItem) => void;
}

export const AddCustomItemModal: React.FC<AddCustomItemModalProps> = ({
  isOpen,
  onClose,
  onAddItem
}) => {
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('CymbalMart Signature');
  const [category, setCategory] = useState<CategoryType>('mains');
  const [unitSize, setUnitSize] = useState('');
  const [unitPrice, setUnitPrice] = useState<number>(4.99);
  const [quantity, setQuantity] = useState<number>(1);
  const [tier, setTier] = useState<BrandTier>('signature');
  const [isMustHave, setIsMustHave] = useState<boolean>(true);
  const [dietaryTag, setDietaryTag] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newItem: ShoppingItem = {
      id: `custom-item-${Date.now()}`,
      name: name.trim(),
      brand: brand.trim() || 'CymbalMart Signature',
      category,
      unitSize: unitSize.trim() || '1 pack',
      unitPrice: Number(unitPrice) || 1.99,
      quantity: Math.max(1, Number(quantity) || 1),
      tier,
      isMustHave,
      dietaryTags: dietaryTag ? [dietaryTag] : []
    };

    onAddItem(newItem);
    setName('');
    setUnitSize('');
    setUnitPrice(4.99);
    setQuantity(1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1A1A1A]/80 backdrop-blur-xs">
      <div className="bg-white border-2 border-[#1A1A1A] max-w-lg w-full p-6 sm:p-8 relative text-left">
        <button
          id="close-add-item-modal"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#1A1A1A]/50 hover:text-[#1A1A1A] hover:bg-[#F1F0EA] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#8B2131] block mb-1">
            Manual Catalog Entry
          </span>
          <h3 className="text-2xl font-black uppercase tracking-tight text-[#1A1A1A]">
            Add Custom Item
          </h3>
          <p className="text-xs text-[#1A1A1A]/60 font-medium">Insert custom grocery, decor, or supply items into the manifest</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="custom-item-name" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
              Item Name *
            </label>
            <input
              id="custom-item-name"
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Sriracha Mayo Dip / Sparklers / Citronella Candle"
              className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="custom-item-category" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Category
              </label>
              <select
                id="custom-item-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as CategoryType)}
                className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              >
                {Object.entries(CATEGORIES).map(([catKey, catMeta]) => (
                  <option key={catKey} value={catKey}>
                    {catMeta.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="custom-item-brand" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Brand / Source
              </label>
              <input
                id="custom-item-brand"
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="e.g. CymbalMart Signature"
                className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label htmlFor="custom-item-unit-size" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Unit Size
              </label>
              <input
                id="custom-item-unit-size"
                type="text"
                value={unitSize}
                onChange={(e) => setUnitSize(e.target.value)}
                placeholder="e.g. 16 oz tub"
                className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>

            <div>
              <label htmlFor="custom-item-price" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Price ($)
              </label>
              <input
                id="custom-item-price"
                type="number"
                step="0.01"
                min="0.10"
                value={unitPrice}
                onChange={(e) => setUnitPrice(parseFloat(e.target.value))}
                className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>

            <div>
              <label htmlFor="custom-item-quantity" className="block text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A] mb-1">
                Quantity
              </label>
              <input
                id="custom-item-quantity"
                type="number"
                min="1"
                max="50"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value, 10))}
                className="w-full px-3.5 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>
          </div>

          <div className="pt-2">
            <label className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-[#1A1A1A] cursor-pointer">
              <input
                id="custom-item-must-have"
                type="checkbox"
                checked={isMustHave}
                onChange={(e) => setIsMustHave(e.target.checked)}
                className="w-4 h-4 accent-[#1A1A1A]"
              />
              <span>Mark as Essential / Must-Have</span>
            </label>
          </div>

          <div className="pt-4 border-t border-[#1A1A1A]/10 flex items-center justify-end space-x-3">
            <button
              id="cancel-add-item-btn"
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider text-[#1A1A1A]/70 hover:text-[#1A1A1A] transition-colors"
            >
              Cancel
            </button>
            <button
              id="confirm-add-item-btn"
              type="submit"
              className="px-6 py-2.5 text-[10px] font-black uppercase tracking-[0.2em] text-white bg-[#1A1A1A] hover:bg-[#8B2131] transition-colors"
            >
              Add to Shopping List
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
