import React, { useState } from 'react';
import { 
  Sparkles, 
  Users, 
  Clock, 
  DollarSign, 
  ChevronRight, 
  Check, 
  Tag, 
  Layers
} from 'lucide-react';
import { EventConfig, BudgetTierPreference } from '../types/party';
import { PARTY_PRESETS, DIETARY_OPTIONS, PartyPreset } from '../data/cymbalmartData';

interface DefineEventStepProps {
  config: EventConfig;
  onChangeConfig: (newConfig: EventConfig) => void;
  onGeneratePlan: () => void;
  isLoading: boolean;
  loadingPhase: string;
}

export const DefineEventStep: React.FC<DefineEventStepProps> = ({
  config,
  onChangeConfig,
  onGeneratePlan,
  isLoading,
  loadingPhase
}) => {
  const [selectedPresetId, setSelectedPresetId] = useState<string | null>('backyard-bbq');

  const totalGuests = (config.guestCount.adults || 0) + (config.guestCount.kids || 0) || 1;
  const costPerGuest = +(config.budget / totalGuests).toFixed(2);

  const handlePresetSelect = (preset: PartyPreset) => {
    setSelectedPresetId(preset.id);
    onChangeConfig({
      ...preset.defaultConfig
    });
  };

  const handleDietaryToggle = (tagLabel: string) => {
    const exists = config.dietaryRestrictions.includes(tagLabel);
    const updated = exists
      ? config.dietaryRestrictions.filter(item => item !== tagLabel)
      : [...config.dietaryRestrictions, tagLabel];
    onChangeConfig({ ...config, dietaryRestrictions: updated });
  };

  const updateAdults = (delta: number) => {
    const next = Math.max(1, (config.guestCount.adults || 0) + delta);
    onChangeConfig({
      ...config,
      guestCount: { ...config.guestCount, adults: next }
    });
  };

  const updateKids = (delta: number) => {
    const next = Math.max(0, (config.guestCount.kids || 0) + delta);
    onChangeConfig({
      ...config,
      guestCount: { ...config.guestCount, kids: next }
    });
  };

  const updateDuration = (delta: number) => {
    const next = Math.max(1, Math.min(12, (config.durationHours || 3) + delta));
    onChangeConfig({ ...config, durationHours: next });
  };

  const handleBudgetChange = (value: number) => {
    onChangeConfig({ ...config, budget: Math.max(20, value) });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-10 sm:py-14 text-left">
      
      {/* Hero Header */}
      <div className="max-w-3xl mb-12">
        <span className="text-[10px] font-bold tracking-[0.25em] text-[#8B2131] uppercase mb-2 block">
          Event Planning & Budget Matrix
        </span>
        <h1 className="text-4xl sm:text-6xl font-black tracking-tighter leading-none uppercase text-[#1A1A1A]">
          CymbalMart Party Shopping Agent
        </h1>
        <p className="mt-4 text-sm sm:text-base text-[#1A1A1A]/70 leading-relaxed font-medium">
          Define your event intent, guest attendance count, and spending parameters. Our autonomous shopping agent computes portion mathematics and creates an itemized cart aligned with your budget.
        </p>
      </div>

      {/* Preset Inspiration Cards */}
      <div className="mb-12">
        <div className="flex items-baseline justify-between mb-4 border-b border-[#1A1A1A]/10 pb-3">
          <div>
            <h2 className="text-xs font-bold tracking-[0.2em] uppercase text-[#1A1A1A]">
              00. Curated Event Archetypes
            </h2>
            <p className="text-[11px] text-[#1A1A1A]/50 uppercase tracking-wider mt-0.5">
              Select a benchmark preset or calibrate manually below
            </p>
          </div>
          <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 bg-[#1A1A1A] text-white">
            6 Presets
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {PARTY_PRESETS.map((preset) => {
            const isSelected = selectedPresetId === preset.id;
            return (
              <div
                key={preset.id}
                id={`preset-${preset.id}`}
                onClick={() => handlePresetSelect(preset)}
                className={`group relative p-5 border transition-all cursor-pointer text-left ${
                  isSelected
                    ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white shadow-md'
                    : 'border-[#1A1A1A]/10 bg-white hover:border-[#1A1A1A]/40'
                }`}
              >
                <div className="flex items-start justify-between">
                  <span className="text-2xl mb-3 block">{preset.emoji}</span>
                  <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 ${
                    isSelected ? 'bg-[#8B2131] text-white' : 'bg-[#1A1A1A]/5 text-[#1A1A1A]'
                  }`}>
                    {preset.badge}
                  </span>
                </div>
                <h3 className={`font-black text-base uppercase tracking-tight ${
                  isSelected ? 'text-white' : 'text-[#1A1A1A]'
                }`}>
                  {preset.title}
                </h3>
                <p className={`text-xs mt-1.5 leading-relaxed line-clamp-2 ${
                  isSelected ? 'text-white/70' : 'text-[#1A1A1A]/60'
                }`}>
                  {preset.subtitle}
                </p>
                <div className={`mt-4 pt-3 border-t flex items-center justify-between text-[10px] font-bold uppercase tracking-wider font-mono ${
                  isSelected ? 'border-white/15 text-white/80' : 'border-[#1A1A1A]/10 text-[#1A1A1A]/70'
                }`}>
                  <span className="text-[#8B2131]">{isSelected && <span className="text-amber-300 mr-1">●</span>}${preset.defaultConfig.budget} TARGET</span>
                  <span>{preset.defaultConfig.guestCount.adults + preset.defaultConfig.guestCount.kids} GUESTS • {preset.defaultConfig.durationHours}H</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Event Configuration Form Matrix */}
      <div className="bg-white border border-[#1A1A1A]/10 p-6 sm:p-10 space-y-10">
        
        {/* Section 1: Event Identity */}
        <div>
          <span className="text-[11px] font-bold tracking-[0.3em] uppercase opacity-40 mb-3 block">
            01. Event Identity & Atmosphere
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label htmlFor="event-name-input" className="block text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A] mb-2">
                Event / Party Title
              </label>
              <input
                id="event-name-input"
                type="text"
                value={config.eventName}
                onChange={(e) => {
                  setSelectedPresetId(null);
                  onChangeConfig({ ...config, eventName: e.target.value });
                }}
                placeholder="e.g. Summer Solstice Soirée"
                className="w-full px-4 py-3 border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] font-semibold text-sm focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>
            <div>
              <label htmlFor="party-theme-input" className="block text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A] mb-2">
                Atmosphere & Vibe Concept
              </label>
              <input
                id="party-theme-input"
                type="text"
                value={config.theme}
                onChange={(e) => {
                  setSelectedPresetId(null);
                  onChangeConfig({ ...config, theme: e.target.value });
                }}
                placeholder="e.g. Rustic Smokehouse & Outdoor Games"
                className="w-full px-4 py-3 border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] font-semibold text-sm focus:outline-hidden focus:border-[#1A1A1A]"
              />
            </div>
          </div>
        </div>

        <div className="border-b border-[#1A1A1A]/10" />

        {/* Section 2: Guest Count & Event Duration */}
        <div>
          <div className="flex items-baseline justify-between mb-4">
            <span className="text-[11px] font-bold tracking-[0.3em] uppercase opacity-40 block">
              02. Attendance & Duration Matrix
            </span>
            <span className="text-[10px] font-bold uppercase tracking-widest px-2.5 py-0.5 bg-[#8B2131] text-white">
              Total: {totalGuests} Guests
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* Adults Counter */}
            <div className="p-5 border border-[#1A1A1A]/10 bg-[#F9F8F3] flex flex-col justify-between">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A]">Adults (18+)</span>
                <span className="text-[9px] font-mono text-[#1A1A1A]/50 uppercase">Full Portions</span>
              </div>
              <div className="flex items-center justify-between">
                <button
                  id="adults-minus-btn"
                  type="button"
                  onClick={() => updateAdults(-1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  -
                </button>
                <span className="text-4xl font-black font-mono text-[#1A1A1A]">{config.guestCount.adults}</span>
                <button
                  id="adults-plus-btn"
                  type="button"
                  onClick={() => updateAdults(1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Kids Counter */}
            <div className="p-5 border border-[#1A1A1A]/10 bg-[#F9F8F3] flex flex-col justify-between">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A]">Kids & Teens</span>
                <span className="text-[9px] font-mono text-[#1A1A1A]/50 uppercase">Snacks/Juices</span>
              </div>
              <div className="flex items-center justify-between">
                <button
                  id="kids-minus-btn"
                  type="button"
                  onClick={() => updateKids(-1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  -
                </button>
                <span className="text-4xl font-black font-mono text-[#1A1A1A]">{config.guestCount.kids}</span>
                <button
                  id="kids-plus-btn"
                  type="button"
                  onClick={() => updateKids(1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Duration Counter */}
            <div className="p-5 border border-[#1A1A1A]/10 bg-[#F9F8F3] flex flex-col justify-between">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#1A1A1A]">Party Duration</span>
                <span className="text-[9px] font-mono text-[#1A1A1A]/50 uppercase">Ice / Drinks</span>
              </div>
              <div className="flex items-center justify-between">
                <button
                  id="duration-minus-btn"
                  type="button"
                  onClick={() => updateDuration(-1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  -
                </button>
                <div className="text-center">
                  <span className="text-4xl font-black font-mono text-[#1A1A1A]">{config.durationHours}</span>
                  <span className="text-[10px] font-bold uppercase text-[#1A1A1A]/50 ml-1">HRS</span>
                </div>
                <button
                  id="duration-plus-btn"
                  type="button"
                  onClick={() => updateDuration(1)}
                  className="w-9 h-9 border border-[#1A1A1A]/30 bg-white text-[#1A1A1A] font-black hover:bg-[#1A1A1A] hover:text-white transition-colors"
                >
                  +
                </button>
              </div>
            </div>

          </div>
        </div>

        <div className="border-b border-[#1A1A1A]/10" />

        {/* Section 3: Budget & Strategy */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-4">
            <span className="text-[11px] font-bold tracking-[0.3em] uppercase opacity-40 block">
              03. Budget Allocation & Sourcing Tier
            </span>
            <div className="text-xs font-mono font-bold text-[#1A1A1A]">
              EST. <span className="text-[#8B2131]">${costPerGuest}</span> / GUEST
            </div>
          </div>

          {/* Budget Showcase & Slider */}
          <div className="p-6 bg-[#F9F8F3] border border-[#1A1A1A]/10 space-y-4">
            <div className="flex items-baseline justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#8B2131]">Total Allocated Budget</span>
                <div className="text-5xl sm:text-6xl font-black font-mono leading-none tracking-tight text-[#1A1A1A] mt-1">
                  ${config.budget}<span className="text-xl align-top">.00</span>
                </div>
              </div>
              <div className="flex items-center bg-white px-3 py-2 border border-[#1A1A1A]/20">
                <span className="text-[#1A1A1A]/40 font-mono font-bold mr-1">$</span>
                <input
                  id="target-budget-input"
                  type="number"
                  min="30"
                  max="1500"
                  step="5"
                  value={config.budget}
                  onChange={(e) => handleBudgetChange(Number(e.target.value))}
                  className="w-24 font-black font-mono text-xl text-[#1A1A1A] focus:outline-hidden text-right"
                />
              </div>
            </div>

            <input
              id="budget-slider"
              type="range"
              min="50"
              max="500"
              step="5"
              value={config.budget}
              onChange={(e) => handleBudgetChange(Number(e.target.value))}
              className="w-full accent-[#1A1A1A] cursor-pointer h-2 bg-[#1A1A1A]/10"
            />

            <div className="flex justify-between text-[9px] font-bold uppercase tracking-wider font-mono text-[#1A1A1A]/50">
              <span>$50 Casual Bites</span>
              <span>$150 Standard Party</span>
              <span>$300 Gourmet Feast</span>
              <span>$500+ Grand Gala</span>
            </div>
          </div>

          {/* Budget Tier Preference Selector */}
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              {
                id: 'value',
                title: 'Value Saver',
                desc: 'Maximizes CymbalMart Everyday Value brands & bulk packs',
                badge: 'Lowest Cost'
              },
              {
                id: 'balanced',
                title: 'Balanced Host',
                desc: 'Mix of CymbalMart Signature & Fresh items with top ratings',
                badge: 'Recommended'
              },
              {
                id: 'premium',
                title: 'Gourmet Specialty',
                desc: 'Artisanal cheeses, prime proteins, and organic bakery options',
                badge: 'Upscale'
              }
            ].map((tier) => {
              const isSelected = config.budgetTierPreference === tier.id;
              return (
                <button
                  key={tier.id}
                  id={`tier-pref-${tier.id}`}
                  type="button"
                  onClick={() => onChangeConfig({ ...config, budgetTierPreference: tier.id as BudgetTierPreference })}
                  className={`p-4 border text-left transition-all ${
                    isSelected
                      ? 'border-[#1A1A1A] bg-[#1A1A1A] text-white shadow-xs'
                      : 'border-[#1A1A1A]/10 bg-white hover:border-[#1A1A1A]/40'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-xs uppercase tracking-wider">{tier.title}</span>
                    <span className={`text-[9px] font-bold uppercase tracking-widest px-2 py-0.5 ${
                      isSelected ? 'bg-[#8B2131] text-white' : 'bg-[#1A1A1A]/5 text-[#1A1A1A]'
                    }`}>
                      {tier.badge}
                    </span>
                  </div>
                  <p className={`text-xs leading-relaxed ${isSelected ? 'text-white/70' : 'text-[#1A1A1A]/60'}`}>
                    {tier.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        <div className="border-b border-[#1A1A1A]/10" />

        {/* Section 4: Dietary Safeguards */}
        <div>
          <span className="text-[11px] font-bold tracking-[0.3em] uppercase opacity-40 mb-3 block">
            04. Dietary Restrictions & Eco Tableware
          </span>

          <div className="flex flex-wrap gap-2">
            {DIETARY_OPTIONS.map((option) => {
              const isSelected = config.dietaryRestrictions.includes(option.label);
              return (
                <button
                  key={option.id}
                  id={`dietary-chip-${option.id}`}
                  type="button"
                  onClick={() => handleDietaryToggle(option.label)}
                  className={`inline-flex items-center space-x-2 px-4 py-2 text-xs font-bold uppercase tracking-wider border transition-all ${
                    isSelected
                      ? 'bg-[#8B2131] text-white border-[#8B2131]'
                      : 'bg-white text-[#1A1A1A] border-[#1A1A1A]/20 hover:border-[#1A1A1A]'
                  }`}
                >
                  <span>{option.icon}</span>
                  <span>{option.label}</span>
                  {isSelected && <Check className="w-3.5 h-3.5 ml-1" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="border-b border-[#1A1A1A]/10" />

        {/* Section 5: Host Special Requests */}
        <div>
          <span className="text-[11px] font-bold tracking-[0.3em] uppercase opacity-40 mb-2 block">
            05. Host Equipment & Sourcing Directives
          </span>
          <p className="text-xs text-[#1A1A1A]/60 mb-3">
            Specify existing equipment (cooler, grill) or items to exclude/emphasize
          </p>

          <textarea
            id="special-requests-input"
            rows={2}
            value={config.specialRequests}
            onChange={(e) => onChangeConfig({ ...config, specialRequests: e.target.value })}
            placeholder="e.g. We already own a cooler and lawn chairs. Please include plenty of cocktail ice, eco-friendly cups, and a vegan appetizer platter."
            className="w-full px-4 py-3 border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] text-sm focus:outline-hidden focus:border-[#1A1A1A] resize-none"
          />
        </div>

        {/* Action Button */}
        <div className="pt-2">
          <button
            id="generate-plan-btn"
            type="button"
            disabled={isLoading}
            onClick={onGeneratePlan}
            className="w-full py-5 px-8 bg-[#1A1A1A] hover:bg-[#8B2131] text-white font-black text-xs uppercase tracking-[0.25em] flex items-center justify-center space-x-3 transition-colors disabled:opacity-75 disabled:cursor-wait"
          >
            {isLoading ? (
              <div className="flex items-center space-x-3">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span className="text-xs tracking-widest">{loadingPhase || 'AI COMPILING SHOPPING PLAN...'}</span>
              </div>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Generate Curated CymbalMart Shopping Plan</span>
                <ChevronRight className="w-4 h-4" />
              </>
            )}
          </button>
          <p className="text-center text-[10px] font-mono uppercase tracking-widest text-[#1A1A1A]/50 mt-3">
            Prices calibrated to CymbalMart store inventory with automatic portion math for {totalGuests} guests.
          </p>
        </div>

      </div>

    </div>
  );
};

