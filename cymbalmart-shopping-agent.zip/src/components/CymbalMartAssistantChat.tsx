import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  ChevronDown,
  Maximize2,
  Minimize2,
  RefreshCw,
  ShoppingBag,
  HelpCircle,
  Clock,
  Car
} from 'lucide-react';
import { EventConfig, PartyPlan } from '../types/party';
import { sendChatMessage, ChatMessage } from '../services/api';

interface CymbalMartAssistantChatProps {
  config: EventConfig;
  plan: PartyPlan | null;
  onApplyRefinePrompt?: (prompt: string) => void;
  isOpenExternal?: boolean;
  onToggleExternal?: () => void;
}

const DEFAULT_SUGGESTIONS = [
  '🧊 How much ice do I need for my guests?',
  '💡 Recommend budget party appetizers',
  '🌴 Tropical cocktail and food ideas',
  '🚗 How does Curbside pickup work?'
];

export const CymbalMartAssistantChat: React.FC<CymbalMartAssistantChatProps> = ({
  config,
  plan,
  onApplyRefinePrompt
}) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [inputText, setInputText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [hasUnread, setHasUnread] = useState<boolean>(false);

  const initialGreeting = `Hello! I'm your **CymbalMart Assistant**. 🛒
I'm here to help you plan the ultimate party! I can advise on:
• **Portion Calculations** (ice, drinks, meat portions)
• **Budget Optimization** (brand substitutions & savings)
• **Themed Menus & Recipes** (appetizers, skewers, cocktails)
• **CymbalMart Curbside Pickup** and bay staging

How can I help you today?`;

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      role: 'assistant',
      content: initialGreeting,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: DEFAULT_SUGGESTIONS
    }
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setHasUnread(false);
      setTimeout(() => inputRef.current?.focus(), 150);
    }
  }, [isOpen, messages]);

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      // Build history for backend API
      const conversationHistory = [...messages, userMsg].map(m => ({
        role: m.role,
        content: m.content
      }));

      const result = await sendChatMessage(conversationHistory, config, plan);

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        role: 'assistant',
        content: result.message,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestions: result.suggestions || DEFAULT_SUGGESTIONS
      };

      setMessages(prev => [...prev, botMsg]);
      if (!isOpen) {
        setHasUnread(true);
      }
    } catch (err) {
      console.error('Chat error:', err);
      setMessages(prev => [
        ...prev,
        {
          id: `bot-err-${Date.now()}`,
          role: 'assistant',
          content: "I'm having trouble connecting right now, but feel free to ask about portion estimates, budget-saving brand substitutions, or CymbalMart Curbside pickup!",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          suggestions: DEFAULT_SUGGESTIONS
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: `welcome-${Date.now()}`,
        role: 'assistant',
        content: initialGreeting,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestions: DEFAULT_SUGGESTIONS
      }
    ]);
  };

  // Helper to render markdown bold and lists nicely
  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return (
      <div className="space-y-1.5 leading-relaxed text-xs">
        {lines.map((line, idx) => {
          if (!line.trim()) return <div key={idx} className="h-1" />;

          // Process markdown bold **text**
          const parts = line.split(/(\*\*.*?\*\*)/g);
          const formattedLine = parts.map((part, pIdx) => {
            if (part.startsWith('**') && part.endsWith('**')) {
              return <strong key={pIdx} className="font-bold text-[#1A1A1A]">{part.slice(2, -2)}</strong>;
            }
            return part;
          });

          if (line.startsWith('• ') || line.startsWith('- ')) {
            return (
              <div key={idx} className="flex items-start space-x-1.5 pl-1.5">
                <span className="text-[#8B2131] font-bold">•</span>
                <span className="flex-1">{formattedLine.slice(1)}</span>
              </div>
            );
          }

          if (/^\d+\.\s/.test(line)) {
            const num = line.match(/^(\d+)\.\s/)?.[1];
            const rest = line.replace(/^\d+\.\s/, '');
            return (
              <div key={idx} className="flex items-start space-x-1.5 pl-1.5">
                <span className="font-mono font-bold text-[#8B2131] text-[11px]">{num}.</span>
                <span className="flex-1">{rest}</span>
              </div>
            );
          }

          return <p key={idx}>{formattedLine}</p>;
        })}
      </div>
    );
  };

  return (
    <>
      {/* Floating Chat Trigger Button */}
      {!isOpen && (
        <div className="fixed bottom-6 right-6 z-40 flex items-center space-x-2 animate-in fade-in slide-in-from-bottom-4">
          <button
            id="cymbalmart-chat-trigger"
            onClick={() => setIsOpen(true)}
            className="group relative flex items-center space-x-2.5 px-4 py-3 bg-[#1A1A1A] text-white hover:bg-[#8B2131] shadow-2xl transition-all duration-200 cursor-pointer border border-white/20"
          >
            <div className="relative">
              <Bot className="w-5 h-5 text-amber-400 group-hover:rotate-12 transition-transform" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse border border-[#1A1A1A]" />
            </div>
            <div className="text-left">
              <span className="text-[11px] font-black uppercase tracking-wider block leading-tight">
                CymbalMart Assistant
              </span>
              <span className="text-[9px] font-mono text-white/70 uppercase tracking-widest block">
                Ask AI Planner
              </span>
            </div>

            {hasUnread && (
              <span className="absolute -top-2 -left-2 bg-[#8B2131] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full border border-white">
                New
              </span>
            )}
          </button>
        </div>
      )}

      {/* Chat Window Panel */}
      {isOpen && (
        <div
          id="cymbalmart-chat-window"
          className={`fixed z-50 transition-all duration-300 bg-white border-2 border-[#1A1A1A] shadow-2xl flex flex-col ${
            isExpanded
              ? 'inset-4 sm:inset-10'
              : 'bottom-4 right-4 sm:bottom-6 sm:right-6 w-[calc(100vw-32px)] sm:w-[420px] h-[580px] max-h-[85vh]'
          }`}
        >
          {/* Header */}
          <div className="p-3.5 bg-[#1A1A1A] text-white flex items-center justify-between border-b border-[#1A1A1A]">
            <div className="flex items-center space-x-2.5">
              <div className="w-7 h-7 bg-[#8B2131] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-amber-300" />
              </div>
              <div>
                <div className="flex items-center space-x-1.5">
                  <h3 className="text-xs font-black uppercase tracking-wider text-white">
                    CymbalMart Assistant
                  </h3>
                  <span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                </div>
                <p className="text-[9px] font-mono text-white/60 uppercase tracking-wider">
                  AI Party Concierge & Shopping Guide
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-1">
              <button
                id="reset-chat-btn"
                title="Restart conversation"
                onClick={handleClearChat}
                className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 transition-colors"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>

              <button
                id="expand-chat-btn"
                title={isExpanded ? 'Collapse' : 'Expand'}
                onClick={() => setIsExpanded(!isExpanded)}
                className="p-1.5 text-white/70 hover:text-white hover:bg-white/10 transition-colors hidden sm:block"
              >
                {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              </button>

              <button
                id="close-chat-btn"
                title="Close chat"
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-white/70 hover:text-white hover:bg-[#8B2131] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Context Ribbon */}
          <div className="bg-[#F1F0EA] px-3.5 py-1.5 border-b border-[#1A1A1A]/10 flex items-center justify-between text-[10px] font-mono text-[#1A1A1A]/80">
            <div className="flex items-center space-x-2 truncate">
              <span className="font-bold text-[#8B2131] uppercase">Context:</span>
              <span className="truncate">
                {config.eventName || 'Party'} ({config.guestCount.adults + config.guestCount.kids} guests • ${config.budget})
              </span>
            </div>
            {plan && (
              <span className="font-bold text-[#1A1A1A] whitespace-nowrap pl-2">
                Cart: ${plan.totalEstimatedCost.toFixed(2)}
              </span>
            )}
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#F9F8F3] text-left">
            {messages.map((msg) => {
              const isBot = msg.role === 'assistant';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isBot ? 'items-start' : 'items-end'}`}
                >
                  <div className="flex items-center space-x-1.5 mb-1 px-1">
                    <span className="text-[9px] font-bold uppercase tracking-wider font-mono text-[#1A1A1A]/50">
                      {isBot ? 'CymbalMart Assistant' : 'You'}
                    </span>
                    <span className="text-[9px] font-mono text-[#1A1A1A]/40">
                      {msg.timestamp}
                    </span>
                  </div>

                  <div
                    className={`max-w-[88%] p-3.5 ${
                      isBot
                        ? 'bg-white border border-[#1A1A1A]/15 text-[#1A1A1A]'
                        : 'bg-[#1A1A1A] text-white border border-[#1A1A1A]'
                    }`}
                  >
                    {isBot ? (
                      renderFormattedContent(msg.content)
                    ) : (
                      <p className="text-xs leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                    )}
                  </div>

                  {/* Suggestion Chips */}
                  {isBot && msg.suggestions && msg.suggestions.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-1.5 max-w-[95%]">
                      {msg.suggestions.map((sug, sIdx) => (
                        <button
                          key={sIdx}
                          onClick={() => handleSendMessage(sug)}
                          className="text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 bg-white hover:bg-[#1A1A1A] hover:text-white border border-[#1A1A1A]/20 text-[#1A1A1A] transition-colors cursor-pointer"
                        >
                          {sug}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {/* Loading Indicator */}
            {isLoading && (
              <div className="flex flex-col items-start">
                <div className="flex items-center space-x-1.5 mb-1 px-1">
                  <span className="text-[9px] font-bold uppercase tracking-wider font-mono text-[#1A1A1A]/50">
                    CymbalMart Assistant
                  </span>
                </div>
                <div className="p-3 bg-white border border-[#1A1A1A]/15 flex items-center space-x-2">
                  <div className="w-2 h-2 bg-[#8B2131] rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-[#1A1A1A] rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 bg-amber-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                  <span className="text-[11px] font-mono text-[#1A1A1A]/60 ml-1">Checking CymbalMart aisles...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Helper Tabs */}
          <div className="bg-[#F1F0EA] px-3 py-1.5 border-t border-[#1A1A1A]/10 flex items-center space-x-2 overflow-x-auto scrollbar-none text-[10px] font-mono uppercase">
            <span className="font-bold text-[#8B2131] whitespace-nowrap">Ask:</span>
            <button
              onClick={() => handleSendMessage('What is the recommended ice quantity?')}
              className="px-2 py-0.5 bg-white border border-[#1A1A1A]/10 hover:border-[#1A1A1A] whitespace-nowrap"
            >
              🧊 Ice Ratios
            </button>
            <button
              onClick={() => handleSendMessage('How to save money with CymbalMart Signature brand?')}
              className="px-2 py-0.5 bg-white border border-[#1A1A1A]/10 hover:border-[#1A1A1A] whitespace-nowrap"
            >
              🏷️ Brand Savings
            </button>
            <button
              onClick={() => handleSendMessage('Explain Free Curbside bay pickup hours')}
              className="px-2 py-0.5 bg-white border border-[#1A1A1A]/10 hover:border-[#1A1A1A] whitespace-nowrap"
            >
              🚗 Curbside Bays
            </button>
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-white border-t border-[#1A1A1A]/20 flex items-center space-x-2"
          >
            <input
              ref={inputRef}
              id="cymbalmart-chat-input"
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              disabled={isLoading}
              placeholder="Ask CymbalMart Assistant (e.g. 'How much ice for 20 guests?')..."
              className="flex-1 px-3 py-2.5 text-xs font-mono border border-[#1A1A1A]/20 bg-[#F9F8F3] text-[#1A1A1A] focus:outline-hidden focus:border-[#1A1A1A] disabled:bg-slate-100"
            />
            <button
              id="send-chat-message-btn"
              type="submit"
              disabled={!inputText.trim() || isLoading}
              className="p-2.5 bg-[#1A1A1A] text-white hover:bg-[#8B2131] disabled:opacity-40 transition-colors cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
