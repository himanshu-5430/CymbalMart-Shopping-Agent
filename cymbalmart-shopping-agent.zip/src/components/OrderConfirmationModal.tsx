import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, 
  ShoppingBag, 
  Calendar, 
  MapPin, 
  Printer, 
  Download, 
  Share2, 
  Clock, 
  Sparkles, 
  X,
  Phone,
  QrCode
} from 'lucide-react';
import { PartyPlan, FulfillmentDetails, EventConfig } from '../types/party';
import { CYMBALMART_STORES } from '../data/cymbalmartData';

interface OrderConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: PartyPlan;
  config: EventConfig;
  fulfillment: FulfillmentDetails;
  orderNumber: string;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  isOpen,
  onClose,
  plan,
  config,
  fulfillment,
  orderNumber
}) => {
  useEffect(() => {
    if (isOpen) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch (e) {
        console.log('Confetti effect triggered');
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const store = CYMBALMART_STORES.find(s => s.id === fulfillment.storeId) || CYMBALMART_STORES[0];
  const totalGuests = (config.guestCount.adults || 0) + (config.guestCount.kids || 0) || 10;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1A1A1A]/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border-2 border-[#1A1A1A] max-w-2xl w-full p-6 sm:p-8 relative my-8 text-left">
        
        <button
          id="close-confirmation-modal-btn"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-[#1A1A1A]/50 hover:text-[#1A1A1A] hover:bg-[#F1F0EA] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Success Header */}
        <div className="text-left pb-6 border-b border-[#1A1A1A]/10">
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#8B2131] block mb-1">
            Transaction Transmitted
          </span>
          <h2 className="text-3xl sm:text-4xl font-black uppercase tracking-tight text-[#1A1A1A]">
            Order Confirmed
          </h2>
          <p className="text-xs text-[#1A1A1A]/70 font-mono mt-1">
            Order Reference: <strong className="text-[#1A1A1A]">{orderNumber}</strong> • Staged at CymbalMart Hub
          </p>
        </div>

        {/* Fulfillment Summary Card */}
        <div className="mt-6 p-4 border border-[#1A1A1A]/10 bg-[#F9F8F3] space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold uppercase tracking-wider text-[#1A1A1A] flex items-center">
              <ShoppingBag className="w-3.5 h-3.5 mr-1.5 text-[#8B2131]" />
              {fulfillment.method === 'pickup' ? 'CymbalMart Curbside Bay' : 'Refrigerated Venue Delivery'}
            </span>
            <span className="font-mono font-bold text-[#8B2131] uppercase">
              {fulfillment.timeSlot}
            </span>
          </div>

          <div className="text-xs text-[#1A1A1A]/80 font-mono space-y-1 pt-2 border-t border-[#1A1A1A]/10">
            {fulfillment.method === 'pickup' ? (
              <>
                <p className="font-bold text-[#1A1A1A] flex items-center">
                  <MapPin className="w-3.5 h-3.5 mr-1 text-[#8B2131]" />
                  {store.name} — {store.address}
                </p>
                <p className="text-[#1A1A1A]/60">
                  Vehicle: <strong>{fulfillment.vehicleDescription || 'Standard Vehicle'}</strong> • Reserved Curbside Staging Bays 1-16
                </p>
              </>
            ) : (
              <p className="font-bold text-[#1A1A1A] flex items-center">
                <MapPin className="w-3.5 h-3.5 mr-1 text-[#8B2131]" />
                Delivery to: {fulfillment.deliveryAddress || 'Host Address on File'}
              </p>
            )}
            <p className="text-[#1A1A1A]/60 flex items-center">
              <Phone className="w-3.5 h-3.5 mr-1 text-[#8B2131]" />
              Host Contact: {fulfillment.contactName} ({fulfillment.contactPhone})
            </p>
          </div>
        </div>

        {/* Party Run-of-Show Checklist */}
        <div className="mt-6">
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#8B2131] block mb-1">
            Host Action Plan
          </span>
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#1A1A1A] mb-3 flex items-center">
            <Clock className="w-4 h-4 mr-1.5 text-[#8B2131]" />
            Party Run-of-Show Checklist
          </h3>
          <div className="space-y-2">
            {plan.partyPrepTips.map((tip, idx) => (
              <div key={idx} className="p-3 border border-[#1A1A1A]/10 bg-[#F9F8F3] flex items-start space-x-3 text-xs">
                <span className="font-bold font-mono text-[#8B2131] uppercase whitespace-nowrap min-w-[95px]">
                  {tip.timeframe}:
                </span>
                <span className="text-[#1A1A1A]/80 font-medium">{tip.task}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Digital Pass / Barcode preview */}
        <div className="mt-6 p-4 bg-[#1A1A1A] text-white flex items-center justify-between">
          <div>
            <span className="text-[9px] uppercase font-bold text-white/50 tracking-[0.2em] block">
              Curbside Express Bay Pass
            </span>
            <span className="text-base font-black font-mono text-amber-400">{orderNumber}</span>
            <p className="text-[10px] font-mono text-white/60 mt-0.5 uppercase">
              {plan.items.length} SKUs • ${plan.totalEstimatedCost.toFixed(2)} Total
            </p>
          </div>
          <div className="bg-white p-2 text-[#1A1A1A] flex flex-col items-center">
            <QrCode className="w-8 h-8" />
            <span className="text-[8px] font-mono font-bold mt-0.5 uppercase">SCAN AT BAY</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 pt-4 border-t border-[#1A1A1A]/10 flex flex-wrap items-center justify-between gap-3">
          <button
            id="print-order-btn"
            onClick={handlePrint}
            className="px-4 py-2.5 text-[10px] font-bold uppercase tracking-wider border border-[#1A1A1A]/20 bg-white hover:bg-[#1A1A1A] hover:text-white flex items-center space-x-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Manifest</span>
          </button>

          <button
            id="done-order-btn"
            onClick={onClose}
            className="px-6 py-2.5 text-[10px] font-black uppercase tracking-[0.2em] text-white bg-[#1A1A1A] hover:bg-[#8B2131] transition-colors"
          >
            Done & Return to Planner
          </button>
        </div>

      </div>
    </div>
  );
};
