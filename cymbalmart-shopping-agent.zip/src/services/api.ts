import { EventConfig, PartyPlan } from '../types/party';

export async function generatePartyPlan(config: EventConfig): Promise<PartyPlan> {
  const response = await fetch('/api/plan-event', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(config),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Server returned ${response.status}: ${errText}`);
  }

  const data: PartyPlan = await response.json();
  return data;
}

export async function refinePartyPlan(
  currentPlan: PartyPlan,
  instruction: string,
  eventConfig: EventConfig
): Promise<{ updatedPlan: PartyPlan; explanation: string }> {
  const response = await fetch('/api/refine-plan', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      currentPlan,
      instruction,
      eventConfig,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Server returned ${response.status}: ${errText}`);
  }

  const data = await response.json();
  return data;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp?: string;
  suggestions?: string[];
}

export async function sendChatMessage(
  messages: Array<{ role: 'user' | 'assistant'; content: string }>,
  eventConfig?: EventConfig,
  currentPlan?: PartyPlan | null
): Promise<{ message: string; suggestions?: string[] }> {
  const response = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messages,
      eventConfig,
      currentPlan,
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Chat API returned ${response.status}: ${errText}`);
  }

  const data = await response.json();
  return data;
}
