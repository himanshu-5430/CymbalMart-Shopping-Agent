import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { DefineEventStep } from './components/DefineEventStep';
import { ReviewListStep } from './components/ReviewListStep';
import { RefineCheckoutStep } from './components/RefineCheckoutStep';
import { CymbalMartAssistantChat } from './components/CymbalMartAssistantChat';
import { VoiceControlHUD } from './components/VoiceControlHUD';
import { useVoiceControl } from './hooks/useVoiceControl';
import { EventConfig, PartyPlan } from './types/party';
import { PARTY_PRESETS } from './data/cymbalmartData';
import { generatePartyPlan, refinePartyPlan } from './services/api';

export default function App() {
  // Default config initialized from the popular Backyard BBQ preset
  const [config, setConfig] = useState<EventConfig>(PARTY_PRESETS[0].defaultConfig);
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [plan, setPlan] = useState<PartyPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingPhase, setLoadingPhase] = useState<string>('');
  const [isRefining, setIsRefining] = useState<boolean>(false);
  const [refinementHistory, setRefinementHistory] = useState<Array<{ prompt: string; explanation: string }>>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Fulfillment & Checkout State for voice sync
  const [selectedFulfillment, setSelectedFulfillment] = useState<'pickup' | 'delivery'>('pickup');
  const [selectedBay, setSelectedBay] = useState<number>(4);
  const [pickupTime, setPickupTime] = useState<string>('Today 4:00 PM - 5:00 PM');
  const [vehicleDetails, setVehicleDetails] = useState<string>('Silver SUV');
  const [orderCompleted, setOrderCompleted] = useState<boolean>(false);

  // Generate initial party plan (Task 1 -> Task 2)
  const handleGeneratePlan = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    setLoadingPhase('Analyzing guest portion requirements...');

    const timer1 = setTimeout(() => setLoadingPhase('Pricing CymbalMart grocery & decor aisles...'), 1200);
    const timer2 = setTimeout(() => setLoadingPhase('Balancing brand tiers & budget limits...'), 2400);

    try {
      const generatedPlan = await generatePartyPlan(config);
      setPlan(generatedPlan);
      setCurrentStep(2);
    } catch (err: any) {
      console.error('Error in plan generation:', err);
      setErrorMessage('We encountered an issue creating the plan, but we loaded a smart fallback curated for your event.');
    } finally {
      clearTimeout(timer1);
      clearTimeout(timer2);
      setIsLoading(false);
      setLoadingPhase('');
    }
  };

  // Refine party plan with AI prompt (Task 3)
  const handleRefineWithAI = async (instruction: string) => {
    if (!plan) return;
    setIsRefining(true);
    setErrorMessage(null);

    try {
      const result = await refinePartyPlan(plan, instruction, config);
      setPlan(result.updatedPlan);
      setRefinementHistory(prev => [
        { prompt: instruction, explanation: result.explanation },
        ...prev
      ]);
    } catch (err: any) {
      console.error('Error in plan refinement:', err);
      setErrorMessage('Could not complete AI refinement, please try again.');
    } finally {
      setIsRefining(false);
    }
  };

  // Reset / start over
  const handleReset = () => {
    if (window.confirm('Start a new party plan? This will clear current items.')) {
      setPlan(null);
      setCurrentStep(1);
      setRefinementHistory([]);
      setConfig(PARTY_PRESETS[0].defaultConfig);
    }
  };

  // Hands-free Voice Control Hook
  const {
    isListening,
    isSupported,
    transcript,
    interimTranscript,
    lastAction,
    isSpeaking,
    ttsEnabled,
    setTtsEnabled,
    commandLogs,
    toggleListening,
    processVoiceCommand
  } = useVoiceControl({
    currentStep,
    setCurrentStep,
    config,
    setConfig,
    plan,
    setPlan,
    onGeneratePlan: handleGeneratePlan,
    onRefineWithAI: handleRefineWithAI,
    onReset: handleReset,
    selectedFulfillment,
    setSelectedFulfillment,
    selectedBay,
    setSelectedBay,
    pickupTime,
    setPickupTime,
    vehicleDetails,
    setVehicleDetails,
    orderCompleted,
    setOrderCompleted
  });

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      
      {/* Navigation Header */}
      <Navbar
        currentStep={currentStep}
        onStepClick={(step) => setCurrentStep(step)}
        plan={plan}
        config={config}
        onReset={handleReset}
        isListening={isListening}
        onToggleListening={toggleListening}
      />

      {/* Global Error Banner if any */}
      {errorMessage && (
        <div className="max-w-4xl mx-auto mt-4 px-4 w-full">
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center justify-between">
            <span>{errorMessage}</span>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-amber-800 font-bold hover:underline ml-2"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Multi-Step CUJ Content */}
      <main className="flex-1 pb-24">
        {currentStep === 1 && (
          <DefineEventStep
            config={config}
            onChangeConfig={setConfig}
            onGeneratePlan={handleGeneratePlan}
            isLoading={isLoading}
            loadingPhase={loadingPhase}
          />
        )}

        {currentStep === 2 && plan && (
          <ReviewListStep
            plan={plan}
            config={config}
            onUpdatePlan={setPlan}
            onProceedToCheckout={() => setCurrentStep(3)}
            onBackToDefine={() => setCurrentStep(1)}
          />
        )}

        {currentStep === 3 && plan && (
          <RefineCheckoutStep
            plan={plan}
            config={config}
            onUpdatePlan={setPlan}
            onRefineWithAI={handleRefineWithAI}
            isRefining={isRefining}
            onBackToReview={() => setCurrentStep(2)}
            refinementHistory={refinementHistory}
          />
        )}
      </main>

      {/* Hands-Free Voice Control HUD */}
      <VoiceControlHUD
        isListening={isListening}
        isSupported={isSupported}
        transcript={transcript}
        interimTranscript={interimTranscript}
        lastAction={lastAction}
        isSpeaking={isSpeaking}
        ttsEnabled={ttsEnabled}
        onToggleTTS={() => setTtsEnabled(!ttsEnabled)}
        onToggleListening={toggleListening}
        commandLogs={commandLogs}
        currentStep={currentStep}
        onSimulateCommand={processVoiceCommand}
      />

      {/* CymbalMart Assistant Chatbot */}
      <CymbalMartAssistantChat
        config={config}
        plan={plan}
        onApplyRefinePrompt={handleRefineWithAI}
      />

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-slate-800">CymbalMart</span>
            <span>•</span>
            <span>Shopping Agent with Hands-Free Voice Control</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Powered by Gemini AI • Real-time budget alignment & grocery inventory
          </p>
        </div>
      </footer>

    </div>
  );
}

